"""
pdf_converter.py
================
Converts a PDF file to Markdown using the MinerU REST API
(POST /file_parse with backend=hybrid-auto-engine).

MinerU API server: http://172.27.22.222:3636
Swagger/docs:      http://172.27.22.222:3636/docs

Output layout (matching MinerU CLI structure):
  output_dir/
    <pdf_stem>/
      <method>/            ← auto | vlm | ocr | txt
        <pdf_stem>.md
        images/
          img_0.png
          ...
"""

from __future__ import annotations

import base64
import io
import json
import logging
import os
import time
import zipfile
from pathlib import Path
from typing import Any, Optional

import requests

logger = logging.getLogger(__name__)

# ── MinerU API configuration ────────────────────────────────────────────────
MINERU_API_BASE_URL: str = os.environ.get(
    "MINERU_API_URL", "http://172.27.22.222:3636"
).rstrip("/")

# Default backend/engine (hybrid-auto-engine combines native text + VLM/OCR)
MINERU_BACKEND: str = "hybrid-auto-engine"

# Supported MinerU methods shown in the UI
MINERU_METHODS = {
    "auto": "Auto (Recommended) — hybrid-auto-engine",
    "vlm":  "VLM — Vision-Language Model (best for complex layouts)",
    "ocr":  "OCR — Pure OCR (fallback for scanned pages)",
    "txt":  "TXT — Text extraction only (fastest, no OCR)",
}

# Request timeout in seconds (override via env MINERU_TIMEOUT)
_DEFAULT_TIMEOUT: int = int(os.environ.get("MINERU_TIMEOUT", "10800"))


def _api_url(path: str) -> str:
    """Build a full API URL from a relative path."""
    return f"{MINERU_API_BASE_URL}/{path.lstrip('/')}"


def is_mineru_available() -> bool:
    """
    Return True if the MinerU API server is reachable.
    Checks GET /health and expects HTTP 200.
    """
    try:
        resp = requests.get(_api_url("/health"), timeout=10)
        return resp.status_code == 200
    except requests.RequestException as exc:
        logger.debug("MinerU API health check failed: %s", exc)
        return False


def _find_output_md(output_dir: Path, pdf_stem: str, method: str) -> Path | None:
    """
    Locate the output .md file produced by MinerU.
    Tries canonical path first, then recursive search.
    """
    canonical = output_dir / pdf_stem / method / f"{pdf_stem}.md"
    if canonical.exists():
        return canonical

    md_files = sorted(output_dir.rglob("*.md"))
    for f in md_files:
        stem_lower = pdf_stem.lower()
        fname_lower = f.name.lower()
        excluded = any(kw in fname_lower for kw in ("content_list", "middle", "model", "layout"))
        if not excluded and stem_lower in fname_lower:
            return f

    return md_files[0] if md_files else None


def _write_image_file(target_dir: Path, images_dir: Path, img_name: str, img_val: Any) -> None:
    """Save an image (base64, URL, or raw bytes) to disk."""
    if not isinstance(img_val, (str, bytes)):
        return

    clean_name = str(img_name).replace("\\", "/").lstrip("/")
    if clean_name.startswith("images/"):
        dest_path = target_dir / clean_name
    else:
        dest_path = images_dir / clean_name

    dest_path.parent.mkdir(parents=True, exist_ok=True)

    if isinstance(img_val, bytes):
        dest_path.write_bytes(img_val)
        return

    # Base64 string handling
    if img_val.startswith("data:image/") or ";base64," in img_val or len(img_val) > 100:
        try:
            b64_str = img_val.split(";base64,")[-1] if ";base64," in img_val else img_val
            img_bytes = base64.b64decode(b64_str)
            dest_path.write_bytes(img_bytes)
            return
        except Exception:
            pass

    # Remote URL handling
    if img_val.startswith("http://") or img_val.startswith("https://"):
        try:
            r = requests.get(img_val, timeout=30)
            if r.status_code == 200:
                dest_path.write_bytes(r.content)
                return
        except Exception as exc:
            logger.warning(f"Failed to download image from {img_val}: {exc}")


def _save_api_results(
    resp: requests.Response,
    output_dir: Path,
    pdf_stem: str,
    method: str
) -> tuple[str, str]:
    """
    Process the MinerU API response and write Markdown + extracted images
    to the target folder in the expected MinerU output layout:
      output_dir/<pdf_stem>/<method>/<pdf_stem>.md
      output_dir/<pdf_stem>/<method>/images/...
    """
    target_dir = output_dir / pdf_stem / method
    target_dir.mkdir(parents=True, exist_ok=True)
    images_dir = target_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    # 1. Handle ZIP binary response
    content_type = resp.headers.get("Content-Type", "").lower()
    if "zip" in content_type or resp.content[:4] == b'PK\x03\x04':
        try:
            with zipfile.ZipFile(io.BytesIO(resp.content)) as zf:
                zf.extractall(target_dir)
            md_file = _find_output_md(output_dir, pdf_stem, method)
            if md_file and md_file.exists():
                md_text = md_file.read_text(encoding="utf-8", errors="replace")
                return md_text, str(md_file)
        except Exception as exc:
            logger.warning("Failed to extract zip from response: %s", exc)

    # 2. Handle JSON / Text response
    md_text = ""
    json_data = None
    try:
        json_data = resp.json()
    except Exception:
        pass

    if json_data:
        res_obj = json_data
        if isinstance(json_data, dict):
            if "results" in json_data and isinstance(json_data["results"], dict):
                sub_keys = list(json_data["results"].keys())
                if sub_keys:
                    res_obj = json_data["results"][sub_keys[0]]
            elif "data" in json_data and isinstance(json_data["data"], dict):
                res_obj = json_data["data"]

        # Extract markdown content string
        if isinstance(res_obj, dict):
            for k in ["md_content", "markdown", "md", "content"]:
                if k in res_obj and isinstance(res_obj[k], str) and res_obj[k].strip():
                    md_text = res_obj[k]
                    break

            # Save auxiliary output files if returned (middle_json, content_list)
            if "middle_json" in res_obj and res_obj["middle_json"]:
                (target_dir / f"{pdf_stem}_middle.json").write_text(
                    json.dumps(res_obj["middle_json"], ensure_ascii=False, indent=2), encoding="utf-8"
                )
            if "content_list" in res_obj and res_obj["content_list"]:
                (target_dir / f"{pdf_stem}_content_list.json").write_text(
                    json.dumps(res_obj["content_list"], ensure_ascii=False, indent=2), encoding="utf-8"
                )

            # Extract & write images
            images = res_obj.get("images", {})
            if isinstance(images, dict):
                for img_name, img_val in images.items():
                    _write_image_file(target_dir, images_dir, img_name, img_val)
            elif isinstance(images, list):
                for item in images:
                    if isinstance(item, dict):
                        name = item.get("name") or item.get("path") or item.get("filename")
                        val = item.get("data") or item.get("content") or item.get("base64") or item.get("url")
                        if name and val:
                            _write_image_file(target_dir, images_dir, name, val)

    if not md_text:
        md_text = resp.text.strip()

    # Save markdown file to canonical path: target_dir / f"{pdf_stem}.md"
    md_file = target_dir / f"{pdf_stem}.md"
    md_file.write_text(md_text, encoding="utf-8")

    logger.info(
        f"Saved MinerU output to {target_dir}: Markdown ({len(md_text):,} chars) "
        f"+ images saved in {images_dir}"
    )

    return md_text, str(md_file)


def convert_pdf_to_markdown(
    pdf_path: str | Path,
    output_dir: str | Path,
    method: str = "auto",
    timeout: int = _DEFAULT_TIMEOUT,
) -> tuple[str, str]:
    """
    Convert a PDF file to Markdown via the MinerU REST API.

    Uses POST /file_parse with backend=hybrid-auto-engine and saves both
    the Markdown file and extracted images into the output folder matching
    the CLI output layout:
      output_dir/<pdf_stem>/<method>/<pdf_stem>.md
      output_dir/<pdf_stem>/<method>/images/

    Args:
        pdf_path:   Absolute path to the input PDF.
        output_dir: Directory where MinerU output files will be written.
        method:     MinerU parse method ("auto" | "vlm" | "ocr" | "txt").
        timeout:    Max seconds to wait for API response.

    Returns:
        (markdown_text, md_file_path) on success.
    """
    pdf_path   = Path(pdf_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not pdf_path.is_file():
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")

    endpoint = _api_url("/file_parse")
    logger.info(
        f"Posting '{pdf_path.name}' to MinerU API {endpoint} (backend={MINERU_BACKEND})"
    )

    with pdf_path.open("rb") as fh:
        files = {"files": (pdf_path.name, fh, "application/pdf")}
        data  = {
            "backend":            MINERU_BACKEND,
            "return_md":          "true",
            "return_images":      "true",
            "return_middle_json": "true",
        }

        try:
            t0   = time.time()
            resp = requests.post(
                endpoint,
                files=files,
                data=data,
                timeout=timeout,
            )
            elapsed = time.time() - t0
            logger.info(
                f"MinerU API responded in {elapsed:.1f} s (HTTP {resp.status_code})"
            )
        except requests.Timeout:
            raise RuntimeError(
                f"MinerU API timed out after {timeout} s. "
                "Try a shorter document or increase MINERU_TIMEOUT."
            )
        except requests.ConnectionError as exc:
            raise ConnectionError(
                f"Cannot reach MinerU API at {MINERU_API_BASE_URL}.\n"
                f"Make sure the server is running.\nDetail: {exc}"
            )

    if resp.status_code != 200:
        raise RuntimeError(
            f"MinerU API returned HTTP {resp.status_code}.\n"
            f"Response: {resp.text[:500]}"
        )

    return _save_api_results(resp, output_dir, pdf_path.stem, method)
