"""
app.py  (v3)
============
Streamlit application — QAP Document Verification AI
Uses MinerU (magic-pdf) + local Ollama LLM.
Includes separate User and Admin portals with authenticated access.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pandas as pd
import streamlit as st

from pdf_converter   import convert_pdf_to_markdown, is_mineru_available, MINERU_METHODS
from section_extractor import extract_sections, SectionNode, TableNode, FigureNode
from section_matcher import match_checklist_to_sections
from llm_verifier    import get_available_ollama_models, verify_checklist_item

# ── Auth & job runner ────────────────────────────────────────────────────────
from auth import (
    verify_credentials,
    verify_credentials_detailed,
    load_ldap_config,
    load_user_history,
    create_job_record,
    delete_history_entry,
    clear_all_history,
    get_last_completed_job,
    get_upload_path,
)
from job_runner import launch_verification_job, is_job_running

# ─────────────────────────────────────────────────────────────────────────────
#  Page config
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="QAP Document Verification AI",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
#  Global CSS — premium dark-mode glassmorphism design
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] { font-family: 'Outfit', sans-serif; }

/* ── Hero title ── */
.hero-title {
    background: linear-gradient(135deg, #6ee7f7 0%, #3b82f6 40%, #a855f7 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 700;
    font-size: 2.6rem;
    line-height: 1.2;
    margin-bottom: 0.25rem;
}
.hero-sub {
    color: #94a3b8;
    font-size: 1.05rem;
    margin-bottom: 1.5rem;
}

/* ── Glass card ── */
.glass-card {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.10);
    border-radius: 14px;
    padding: 1.25rem 1.5rem;
    margin-bottom: 1.25rem;
    backdrop-filter: blur(12px);
    transition: border-color 0.25s, box-shadow 0.25s, transform 0.2s;
}
.glass-card:hover {
    border-color: rgba(99,179,237,0.35);
    box-shadow: 0 8px 32px rgba(0,0,0,0.25);
    transform: translateY(-2px);
}

/* ── Section badges ── */
.badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.78rem;
    font-weight: 600;
    letter-spacing: 0.02em;
}
.badge-verified  { color:#34d399; background:rgba(52,211,153,0.12); border:1px solid rgba(52,211,153,0.25);}
.badge-partial   { color:#fbbf24; background:rgba(251,191,36,0.12);  border:1px solid rgba(251,191,36,0.25);}
.badge-missing   { color:#f87171; background:rgba(248,113,113,0.12); border:1px solid rgba(248,113,113,0.25);}
.badge-error     { color:#94a3b8; background:rgba(148,163,184,0.12); border:1px solid rgba(148,163,184,0.25);}

/* ── Tree node label ── */
.tree-label {
    font-size: 0.9rem;
    font-weight: 600;
    color: #7dd3fc;
    margin-right: 6px;
}
.tree-label-special {
    color: #c4b5fd;
}
.tree-label-table {
    color: #86efac;
}
.tree-label-figure {
    color: #fda4af;
}

/* ── Metric tile ── */
.metric-tile {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 10px;
    padding: 1rem 1.25rem;
    text-align: center;
}
.metric-tile .val { font-size: 2rem; font-weight: 700; }
.metric-tile .lbl { font-size: 0.8rem; color: #94a3b8; }

/* ── Tier chip ── */
.tier-chip {
    font-size: 0.72rem;
    padding: 1px 8px;
    border-radius: 10px;
    font-weight: 600;
}
.tier-exact    { background: rgba(52,211,153,0.18); color: #34d399; }
.tier-fuzzy    { background: rgba(251,191,36,0.18);  color: #fbbf24; }
.tier-synonym  { background: rgba(139,92,246,0.18); color: #a78bfa; }
.tier-embedding{ background: rgba(99,179,237,0.18);  color: #60a5fa; }
.tier-low      { background: rgba(148,163,184,0.12); color: #94a3b8; }

/* ── Progress bar colour ── */
.stProgress > div > div > div { background: linear-gradient(90deg,#3b82f6,#a855f7) !important; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
#  DOCX Checklist Parser & Prompt Auto-Generator
# ─────────────────────────────────────────────────────────────────────────────
def load_default_checklist_from_docx(docx_path="QAP_checklist.docx") -> list[dict]:
    try:
        import docx
        doc = docx.Document(docx_path)
    except Exception:
        return DEFAULT_CHECKLIST

    expected_sections = [
        ("Amendment sheet/Revision History", "Is there an amendment sheet or revision history?", "Verify if the document contains an Amendment sheet / Revision History."),
        ("Introduction", "Is the introduction, scope, and purpose defined?", "Details of the QAP/QT/AT Document to be given."),
        ("List of tables", "Is the list of tables present?", "Include all the Tables."),
        ("List of Figures", "Is the list of figures present?", "Include all the Figures."),
        ("Abbreviations", "Is there a list of abbreviations or glossary?", "Include all the abbreviations."),
        ("Standards", "Are the manufacturing and test standards documented?", ""),
        ("Deliverables", "Is the delivery set or list of deliverables documented?", "Give in detail as per Supply Order (Reports, Etc…)."),
        ("Reference Doc", "Are references and governing documents listed?", "Verify if references like Supply Order, ENTEST Doc of concern project, T.S, QT/AT Documents, BoM, MDI & IPD Documents are listed."),
        ("Unit block diagram & Description", "Is the unit block diagram and description defined?", "Showing the Inputs & Outputs of the Unit."),
        ("Technical specifications (E&M)", "Are electrical and mechanical specifications detailed?", "Technical Specs of the Supply order which includes all Electrical (Input Specs, Output Specs, Connectors & Mechanical specs)."),
        ("Knock Down Diagram & description", "Is the knock down diagram and description included?", "It should give the unit/sub system in detailed view so that we can understand how many PCB’s & Connectors are in the unit. Include list of connectors, Connector Pin Assignments, Analog/Digital signals."),
        ("Internal wiring diagram", "Is the internal wiring diagram documented?", "Detail wiring diagram to be given which includes all PCB’s connectors and how they are connected through Wires/cables."),
        ("Retention checks", "Are torque and retention checks defined?", "How much torque to be applied to each connector (Series-II/Series-III/ D-sub connectors)."),
        ("Axis Diagram", "Is the unit axis diagram included?", "Diagram should represent the X, Y & Z axis and connectors of the unit also should be shown clearly, and if there are any Longitudinal, Lateral, FORE, AFT, UP, DOWN, RIGHT, LEFT to be given clearly."),
        ("All functional tests & their procedures", "Are all functional tests and procedures specified?", "Mention all the parameters and their functional procedure clearly. Include CEMILAC, QT & AT, SOFT Tests (only specification no need for procedures)."),
        ("QA Matrix", "Is the Quality Assurance matrix present?", "Each & Every stage should be marked as Performed /Review/ Verify/ witness for the vendor, Project/User, R & QA. Check for Raw material, Mechanical, KOP, Bare PCB, Assembled PCB, Card level, Cemilac Screening, wiring, retention, Integration, Initial/Final cold & functional, and QT/AT tests."),
        ("Process Flow chart & description", "Is the process flow chart and description included?", "Bare PCB to Final Assembly of the product and Delivery of the unit (Full Process flow to be given step by Step). In description each stage to be defined clearly what should be done (e.g. Bare PCB magnification)."),
        ("Process inspection reports", "Are process inspection reports and templates present?", "Check for formats: test setup details, kop, bare, baking, populated, potting, conformal coating, and Failure analysis Report."),
        ("Safety & Handlings", "Are safety and handling guidelines included?", "What are the safety measures & how to handle the Unit & PCB’s… to be given."),
        ("Storage", "Are storage guidelines and cap requirements defined?", "What is the guideline of the storage, for ex. Connectors should be covered with dusting caps."),
        ("Packaging instructions", "Are packaging instructions documented?", "Verify if packaging instructions are specified in the document."),
        ("Conformance reports(QT/AT)", "Are conformance reports for QT/AT tests included?", "Include conformance reports and test results for all tests.")
    ]

    standards_desc = "Verify if the document refers to these standards:\n"
    if doc.tables:
        for row in doc.tables[0].rows[1:]:
            cells = [c.text.strip() for c in row.cells]
            if len(cells) >= 3:
                standards_desc += f"- {cells[1]}: {cells[2]}\n"
    else:
        standards_desc += "- MIL-STD-883: Test Method Standards – Microcircuits\n- MIL-STD-202: Test for Electrical/Electronic Parts\n- MIL-STD-38535: Micro Circuits Manufacturing\n- JSS 0256-01: Environmental test methods for guided missiles"

    checklist = []
    for item_id, (sect, quest, default_prompt) in enumerate(expected_sections, 1):
        prompt = default_prompt
        if sect == "Standards":
            prompt = standards_desc.strip()
            
        checklist.append({
            "id": item_id,
            "section_name": sect,
            "question": quest,
            "prompt": prompt
        })
        
    return checklist


def generate_prompt_with_ollama(section_name: str, question: str, model_name: str = "gpt-oss:20b") -> str:
    import requests
    url = "http://172.27.30.222:12000/api/chat"
    system_prompt = (
        "You are an expert QAP verification assistant. Generate a concise, specific prompt (1 to 2 sentences) "
        "directing an LLM on what to verify in the document section. "
        "The generated prompt should tell the LLM exactly what to look for based on the section name and the verification question."
    )
    user_msg = (
        f"Section Name: {section_name}\n"
        f"Verification Question: {question}\n\n"
        f"Generate only the prompt text, without any introductory or concluding remarks. Make it concise and direct."
    )
    
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_msg}
        ],
        "options": {"temperature": 0.2},
        "stream": False
    }
    
    try:
        resp = requests.post(url, json=payload, timeout=10)
        if resp.status_code == 200:
            prompt_text = resp.json()["message"]["content"].strip()
            if prompt_text.startswith('"') and prompt_text.endswith('"'):
                prompt_text = prompt_text[1:-1].strip()
            return prompt_text
    except Exception:
        pass
        
    return f"Verify if the document contains a section for {section_name} to answer: {question}"


#  Default checklist
# ─────────────────────────────────────────────────────────────────────────────
DEFAULT_CHECKLIST = [
    {"id":  1, "section_name": "Amendments Record Sheet",
     "question": "Is there an amendment or revision history table?",
     "prompt": "Verify if the document contains an Amendments Record Sheet, revision history table, or record of amendments including fields for issue date, revision number, and approvals."},
    {"id":  2, "section_name": "Introduction",
     "question": "Is the system introduction, scope, and purpose defined?",
     "prompt": "Check if there is an introduction section explaining the system's purpose and the scope of this Quality Assurance Plan."},
    {"id":  3, "section_name": "List of Tables",
     "question": "Is the list of tables present?",
     "prompt": "Verify if a List of Tables is present in the front matter of the document."},
    {"id":  4, "section_name": "List of Figures",
     "question": "Is the list of figures present?",
     "prompt": "Verify if a List of Figures is present in the front matter of the document."},
    {"id":  5, "section_name": "Abbreviations",
     "question": "Is there a comprehensive list of acronyms or abbreviations?",
     "prompt": "Verify if an Abbreviations list or Glossary of terms exists, mapping abbreviations to their full forms."},
    {"id":  6, "section_name": "Deliverables / Delivery Set",
     "question": "Is the delivery set or list of deliverables documented?",
     "prompt": "Check for a delivery list, delivery set, or deliverables specification showing what items are delivered to the customer."},
    {"id":  7, "section_name": "Storage Details",
     "question": "Are storage guidelines, shelf life, and conditions specified?",
     "prompt": "Verify if storage requirements (temperature ranges, RH, ESD boxes, shelf life) are clearly defined."},
    {"id":  8, "section_name": "Packaging Instructions",
     "question": "Are unit packaging instructions documented?",
     "prompt": "Check if there are instructions for packaging the unit safely before transportation."},
    {"id":  9, "section_name": "PCB Inspection Report Template",
     "question": "Is there a bare/populated PCB inspection report template?",
     "prompt": "Verify if a populated PCB inspection stage clearance report template is present."},
    {"id": 10, "section_name": "Quality Assurance Matrix",
     "question": "Is the QA matrix for mechanical and electrical components present?",
     "prompt": "Check if there is a detailed QA matrix mapping inspection parameters, methods, and acceptance criteria."},
    {"id": 11, "section_name": "Safety Precautions",
     "question": "Are safety precautions for assembly or handling included?",
     "prompt": "Verify if the document lists safety guidelines, HV handling, ESD warnings, or basic safety instructions."},
    {"id": 12, "section_name": "Retention Checks / Records Control",
     "question": "Are record retention guidelines specified?",
     "prompt": "Check if there is a policy for controlling records, specifying how long quality records must be retained."},
    {"id": 13, "section_name": "Incoming Inspection Stage",
     "question": "Is there a process defined for incoming component inspection?",
     "prompt": "Check if incoming goods inspection or raw material verification steps are documented."},
    {"id": 14, "section_name": "BOM Inspection",
     "question": "Is Bill of Materials inspection mentioned?",
     "prompt": "Verify if the QAP specifies stage checks for verifying populated PCBs against the authorized BOM."},
    {"id": 15, "section_name": "Traceability and Identification",
     "question": "Are identification and serial number tracking defined?",
     "prompt": "Check for traceability guidelines detailing how parts, lot codes, or serial numbers are logged."},
    {"id": 16, "section_name": "Qualification Test (QT) Flow",
     "question": "Is the Qualification Test flow chart or sequence present?",
     "prompt": "Verify if there is a flowchart or step-by-step QT procedure covering environmental stress, vibration, and temperature testing."},
    {"id": 17, "section_name": "Acceptance Test (AT) Flow",
     "question": "Is the Acceptance Test sequence or procedure defined?",
     "prompt": "Check for an ATP flow chart or matrix detailing how units are screened before shipment."},
    {"id": 18, "section_name": "EMI/EMC Testing",
     "question": "Are EMI/EMC testing standards and limits documented?",
     "prompt": "Verify if EMI/EMC testing requirements (CE102, CS101, CS114, RE102, RS103 per MIL-STD-461) are specified."},
    {"id": 19, "section_name": "Test Templates / Inspection Reports",
     "question": "Are template report forms included for testing?",
     "prompt": "Check if the annexures section has empty forms/reports (Housing Inspection, Card cold checks, Conformal coating report)."},
    {"id": 20, "section_name": "Governing / Reference Documents",
     "question": "Are supply orders, reference standards, and reference drawings listed?",
     "prompt": "Verify if a list of reference drawings, BOM drawings, supply orders, or military standards is documented."}
]

# ─────────────────────────────────────────────────────────────────────────────
#  Session state
# ─────────────────────────────────────────────────────────────────────────────
def _init_state() -> None:
    loaded_checklist = None
    checklist_json_path = Path("qap_checklist.json")
    if checklist_json_path.exists():
        try:
            with open(checklist_json_path, "r", encoding="utf-8") as f:
                loaded_checklist = json.load(f)
        except Exception:
            pass
            
    if not loaded_checklist:
        loaded_checklist = load_default_checklist_from_docx()
        try:
            with open(checklist_json_path, "w", encoding="utf-8") as f:
                json.dump(loaded_checklist, f, indent=2)
        except Exception:
            pass

    ollama_models = get_available_ollama_models()
    default_model = "gpt-oss:20b"
    if ollama_models:
        if "gpt-oss:20b" in ollama_models:
            default_model = "gpt-oss:20b"
        elif "gpt-oss:latest" in ollama_models:
            default_model = "gpt-oss:latest"
        else:
            default_model = ollama_models[0]

    defaults = {
        "checklist":            loaded_checklist,
        "extraction_result":    None,
        "verification_results": {},
        "doc_name":             "",
        "selected_model":       default_model,
        "selected_method":      "auto",
        "enable_image_desc":    False,
        "vision_model":         None,
        "use_embeddings":       True,
        "top_k":                2,
        "admin_authenticated":  False,
        # ── User auth ──
        "logged_in_user":       None,
        "last_loaded_job_id":   None,   # job_id of results currently shown
        "last_activity":        None,   # timestamp of last activity
        "session_expired":      False,  # flag to show session expired message
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()

# ─────────────────────────────────────────────────────────────────────────────
#  Session Timeout Check (Automatic Logout after Inactivity)
# ─────────────────────────────────────────────────────────────────────────────
SESSION_TIMEOUT_SECONDS = 5 * 3600  # 5 hours - change this value as desired

def check_session_timeout() -> None:
    """Check if the user session has timed out due to inactivity."""
    import time
    if st.session_state.get("logged_in_user"):
        curr_time = time.time()
        last_act = st.session_state.get("last_activity")
        if last_act is not None:
            elapsed = curr_time - last_act
            if elapsed > SESSION_TIMEOUT_SECONDS:
                # Log out the user
                st.session_state.logged_in_user = None
                st.session_state.last_loaded_job_id = None
                st.session_state.verification_results = {}
                st.session_state.doc_name = ""
                st.session_state.session_expired = True
                st.session_state.last_activity = None
                st.rerun()
        st.session_state.last_activity = curr_time

check_session_timeout()


# ─────────────────────────────────────────────────────────────────────────────
#  Estimation Helpers
# ─────────────────────────────────────────────────────────────────────────────
def get_pdf_page_count(pdf_path: Path) -> int:
    try:
        import pypdf
        reader = pypdf.PdfReader(pdf_path)
        return len(reader.pages)
    except Exception:
        try:
            content = pdf_path.read_bytes()
            pages = content.count(b"/Type /Page")
            if pages == 0:
                pages = content.count(b"/Type/Page")
            return max(1, pages)
        except Exception:
            return 5


def estimate_verification_time(doc_path: Path, num_items: int, is_pdf: bool) -> int:
    if is_pdf:
        page_count = get_pdf_page_count(doc_path)
        # Average magic-pdf parsing time: ~10 seconds startup + 2.0 seconds per page
        extraction_est = 10 + int(page_count * 2.0)
    else:
        extraction_est = 2
    
    # Average LLM verification time per checklist item
    # Assuming local Ollama takes ~1.5 seconds per item
    verification_est = int(num_items * 1.5)
    
    # Image description overhead if enabled
    vision_est = 0
    if st.session_state.get("enable_image_desc", False):
        vision_est = 15
        
    return extraction_est + verification_est + vision_est

# ─────────────────────────────────────────────────────────────────────────────
#  Helper: render a tier chip
# ─────────────────────────────────────────────────────────────────────────────
def _tier_chip(tier: str) -> str:
    base = tier.split("_")[0]
    cls  = {
        "exact":     "tier-exact",
        "fuzzy":     "tier-fuzzy",
        "synonym":   "tier-synonym",
        "embedding": "tier-embedding",
    }.get(base, "tier-low")
    return f'<span class="tier-chip {cls}">{tier}</span>'

# ─────────────────────────────────────────────────────────────────────────────
#  Sidebar Navigation & Settings
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🧭 Navigation")
    page_mode = st.radio("Go to Page", ["User Portal", "Admin Portal"])
    st.markdown("---")

    if page_mode == "Admin Portal":
        if st.session_state.admin_authenticated:
            st.markdown("## ⚙️ Settings")
            st.subheader("LLM Model")
            ollama_models = get_available_ollama_models()
            if ollama_models:
                try:
                    default_idx = ollama_models.index(st.session_state.selected_model)
                except ValueError:
                    default_idx = 0
                    if "gpt-oss:20b" in ollama_models:
                        default_idx = ollama_models.index("gpt-oss:20b")
                    elif "gpt-oss:latest" in ollama_models:
                        default_idx = ollama_models.index("gpt-oss:latest")
                selected_model = st.selectbox("Ollama model", ollama_models, index=default_idx)
                st.session_state.selected_model = selected_model
            else:
                st.warning("Ollama not detected on `172.27.30.222:12000`. Make sure `ollama serve` is running.")
                selected_model = st.text_input("Model name (manual)", st.session_state.selected_model)
                st.session_state.selected_model = selected_model

            st.subheader("PDF Conversion")
            mineru_ok = is_mineru_available()
            if mineru_ok:
                st.success("✅ MinerU (magic-pdf) detected")
            else:
                st.info("ℹ️ MinerU not detected — upload a pre-converted `.md` file.")
            
            try:
                m_list = list(MINERU_METHODS.keys())
                default_m_idx = m_list.index(st.session_state.selected_method)
            except ValueError:
                default_m_idx = 0
                
            selected_method = st.selectbox(
                "Extraction method",
                m_list,
                index=default_m_idx,
                format_func=lambda x: MINERU_METHODS[x],
            )
            st.session_state.selected_method = selected_method

            st.subheader("🖼️ Image Descriptions")
            enable_image_desc = st.checkbox(
                "Describe images using Vision LLM",
                value=st.session_state.enable_image_desc,
                help="Use a local vision model (e.g., llava, llama3.2-vision) to analyze and generate descriptions for images/diagrams in the document.",
            )
            st.session_state.enable_image_desc = enable_image_desc
            
            vision_model = st.session_state.vision_model
            if enable_image_desc:
                vision_candidates = [
                    m for m in ollama_models 
                    if any(x in m.lower() for x in ("gemma3:4b","gemma4:e4b","llava", "vision", "bakllava", "minicpm", "moondream"))
                ]
                if vision_candidates:
                    try:
                        v_idx = vision_candidates.index(st.session_state.vision_model)
                    except ValueError:
                        v_idx = 0
                    vision_model = st.selectbox("Vision Model", vision_candidates, index=v_idx)
                else:
                    st.warning("No vision models detected. Pull one, e.g., `ollama pull llava`.")
                    try:
                        v_idx = ollama_models.index(st.session_state.vision_model)
                    except ValueError:
                        v_idx = 0
                    vision_model = st.selectbox("Vision Model (All)", ollama_models if ollama_models else ["llava"], index=v_idx)
                st.session_state.vision_model = vision_model

            st.subheader("Matching Settings")
            use_embeddings = st.checkbox("Semantic match (nomic-embed-text)", value=st.session_state.use_embeddings)
            st.session_state.use_embeddings = use_embeddings
            
            top_k = st.slider("Top-K matches per item", min_value=1, max_value=5, value=st.session_state.top_k)
            st.session_state.top_k = top_k

            st.subheader("🔑 LDAP Authentication")
            ldap_cfg = load_ldap_config()
            if ldap_cfg.get("ldap_enabled", False):
                st.success(f"✅ LDAP Enabled (`{ldap_cfg.get('server_uri', 'N/A')}`)")
                st.caption(f"Bind Method: `{ldap_cfg.get('bind_method', 'direct_bind')}`")
            else:
                st.info("ℹ️ LDAP Disabled (Using local `users_config.json`)")

            st.markdown("---")
            if st.button("🔓 Logout"):
                st.session_state.admin_authenticated = False
                st.rerun()

        else:
            st.info("🔐 Please authenticate to access settings.")
    else:
        # ── User Portal sidebar: show login status ────────────────────────
        if st.session_state.logged_in_user:
            uname = st.session_state.logged_in_user
            st.markdown(
                f"""
                <div style="background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.25);
                            border-radius:10px;padding:10px 14px;margin-bottom:8px;">
                  <div style="font-size:0.8rem;color:#94a3b8;margin-bottom:2px;">Signed in as</div>
                  <div style="font-size:1rem;font-weight:700;color:#6ee7f7;">👤 {uname}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            if st.button("🔓 Sign Out", use_container_width=True, key="user_logout_btn"):
                st.session_state.logged_in_user     = None
                st.session_state.last_loaded_job_id = None
                st.session_state.verification_results = {}
                st.session_state.doc_name = ""
                st.rerun()
        else:
            st.markdown("🌐 **User Portal**")
            st.caption("Please log in to access the portal.")

# ─────────────────────────────────────────────────────────────────────────────
#  Helper: render full interactive results table (reused across tabs)
# ─────────────────────────────────────────────────────────────────────────────
def _render_results_table(ver_list: list, doc_name: str, key_suffix: str = "") -> None:
    """Render compliance audit metrics + downloadable table for a result set."""
    total = len(ver_list)
    if total == 0:
        st.info("No results to display.")
        return

    verified = sum(1 for x in ver_list if x["llm_status"] == "Verified")
    partial  = sum(1 for x in ver_list if x["llm_status"] == "Partially Verified")
    missing  = sum(1 for x in ver_list if x["llm_status"] in ("Not Found", "Failed Verification"))

    mc1, mc2, mc3, mc4 = st.columns(4)
    mc1.metric("Total Rules Tested", total)
    mc2.metric("✅ Verified", verified, delta=f"{verified/total*100:.0f}%")
    mc3.metric("⚠️ Partially Verified", partial, delta=f"{partial/total*100:.0f}%")
    mc4.metric("❌ Missing / Failed", missing, delta=f"-{missing/total*100:.0f}%")

    rpt = [
        f"# QAP Audit Report — {doc_name}\n",
        f"**Summary:** {verified}/{total} items verified.\n",
        "| ID | Section | Status | Best Match |\n|---|---|---|---|",
    ]
    for r in ver_list:
        best_hdg = r["tree_matches"][0]["matched_heading"] if r.get("tree_matches") else "—"
        rpt.append(f"| {r['checklist_id']} | {r['checklist_section']} | {r['llm_status']} | {best_hdg} |")
    rpt.append("\n## Detailed Findings\n")
    for r in ver_list:
        rpt.append(f"### {r['checklist_id']}. {r['checklist_section']}")
        rpt.append(f"- **Status:** {r['llm_status']}")
        rpt.append(f"- **Summary:** {r['llm_summary']}")
        rpt.append(f"- **Evidence:** {r['llm_evidence']}")
        rpt.append(f"- **Gaps:** {r['llm_gaps']}\n")

    st.download_button(
        "📥 Download Compliance Audit Report (Markdown)",
        data="\n".join(rpt),
        file_name="qap_compliance_report.md",
        mime="text/markdown",
        key=f"compliance_report_dl{key_suffix}"
    )

    st.markdown("### 📊 Verification Compliance Audit Results")

    def _map_status(status):
        if status == "Verified":
            return "✅ Verified"
        elif status == "Partially Verified":
            return "⚠️ Partially Verified"
        elif status in ("Not Found", "Failed Verification"):
            return "❌ Missing / Failed"
        return f"❓ {status}"

    table_rows = []
    for r in ver_list:
        best_section = r["tree_matches"][0]["matched_heading"] if r.get("tree_matches") else "—"
        table_rows.append({
            "ID": r["checklist_id"],
            "Requirement/Section": r["checklist_section"],
            "Verification Question": r["question"],
            "Status": _map_status(r["llm_status"]),
            "Audit Findings Summary": r["llm_summary"],
            "Identified Evidence": r["llm_evidence"] if r["llm_evidence"] else "N/A",
            "Gaps & Recommendations": r["llm_gaps"] if r["llm_gaps"] else "None",
            "Matched Location": best_section
        })

    df_results = pd.DataFrame(table_rows)
    st.dataframe(
        df_results,
        column_config={
            "ID": st.column_config.NumberColumn("ID", width="small"),
            "Requirement/Section": st.column_config.TextColumn("Requirement/Section", width="medium"),
            "Verification Question": st.column_config.TextColumn("Verification Question", width="large"),
            "Status": st.column_config.TextColumn("Status", width="medium"),
            "Audit Findings Summary": st.column_config.TextColumn("Audit Findings Summary", width="large"),
            "Identified Evidence": st.column_config.TextColumn("Identified Evidence", width="large"),
            "Gaps & Recommendations": st.column_config.TextColumn("Gaps & Recommendations", width="large"),
            "Matched Location": st.column_config.TextColumn("Matched Location", width="medium")
        },
        use_container_width=True,
        hide_index=True,
        key=f"results_dataframe{key_suffix}"
    )


# ─────────────────────────────────────────────────────────────────────────────
#  Main Portal Body Routing
# ─────────────────────────────────────────────────────────────────────────────
if page_mode == "User Portal":

    # ── Not logged in → show login page ──────────────────────────────────────
    if not st.session_state.logged_in_user:
        st.markdown("<div class='hero-title'>🛡️ QAP Document Verification</div>", unsafe_allow_html=True)
        st.markdown(
            "<div class='hero-sub'>Sign in to upload documents, run compliance audits, and view your results history.</div>",
            unsafe_allow_html=True,
        )

        col_l, col_c, col_r = st.columns([1, 1.6, 1])
        with col_c:
            if st.session_state.get("session_expired"):
                st.warning("⚠️ Your session has expired due to inactivity. Please sign in again.")
                st.session_state.session_expired = False

            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown("""
            <div class="glass-card" style="padding:2rem 2.2rem;">
              <h3 style="margin-top:0;text-align:center;background:linear-gradient(135deg,#6ee7f7,#3b82f6);
                         -webkit-background-clip:text;-webkit-text-fill-color:transparent;
                         font-weight:700;">Welcome Back</h3>
              <p style="text-align:center;color:#94a3b8;font-size:0.9rem;margin-bottom:0.5rem;">
                Enter your credentials to access your workspace.
              </p>
            </div>
            """, unsafe_allow_html=True)

            with st.form("user_login_form", clear_on_submit=False):
                login_user = st.text_input(
                    "Username", placeholder="Enter your username",
                    key="login_username_input"
                )
                login_pwd = st.text_input(
                    "Password", type="password", placeholder="Enter your password",
                    key="login_password_input"
                )
                submitted = st.form_submit_button(
                    "🔑 Sign In", use_container_width=True, type="primary"
                )
                if submitted:
                    if not login_user.strip() or not login_pwd:
                        st.error("Please enter both username and password.")
                    elif verify_credentials(login_user.strip(), login_pwd):
                        st.session_state.logged_in_user     = login_user.strip().lower()
                        st.session_state.last_loaded_job_id = None
                        st.session_state.last_activity      = time.time()
                        st.rerun()
                    else:
                        st.error("❌ Invalid username or password.")

    # ── Logged in → show full User Portal ────────────────────────────────────
    else:
        username = st.session_state.logged_in_user

        # Inject Client-Side JavaScript Inactivity Timeout Check
        import streamlit.components.v1 as components
        components.html(
            """
            <script>
            // Inactivity timeout of 5 hours in milliseconds (5 * 60 * 60 * 1000)
            const timeoutMs = 5 * 60 * 60 * 1000;
            let idleTimer;

            function resetTimer() {
                clearTimeout(idleTimer);
                idleTimer = setTimeout(triggerLogout, timeoutMs);
            }

            function triggerLogout() {
                try {
                    window.parent.location.reload();
                } catch (e) {
                    window.location.reload();
                }
            }

            try {
                const parentDoc = window.parent.document;
                parentDoc.addEventListener('mousemove', resetTimer);
                parentDoc.addEventListener('keypress', resetTimer);
                parentDoc.addEventListener('click', resetTimer);
                parentDoc.addEventListener('scroll', resetTimer);
                parentDoc.addEventListener('touchstart', resetTimer);
            } catch (e) {
                document.addEventListener('mousemove', resetTimer);
                document.addEventListener('keypress', resetTimer);
                document.addEventListener('click', resetTimer);
                document.addEventListener('scroll', resetTimer);
            }

            resetTimer();
            </script>
            """,
            height=0,
            width=0
        )

        st.markdown("<div class='hero-title'>🛡️ QAP Document Verification</div>", unsafe_allow_html=True)
        st.markdown(
            f"<div class='hero-sub'>Welcome back, <strong style='color:#6ee7f7'>{username}</strong>! "
            "Upload your QAP document and run an AI-powered compliance audit.</div>",
            unsafe_allow_html=True,
        )

        TAB_UPLOAD_USER, TAB_HISTORY, TAB_QUESTIONS = st.tabs(["📤 Upload & Verify", "📜 My History", "📋 Checklist Questions"])

        # ══════════════════════════════════════════════════════════════════════
        #  TAB A — Upload & Verify
        # ══════════════════════════════════════════════════════════════════════
        with TAB_UPLOAD_USER:

            # ── Auto-load last completed result on login ──────────────────
            last_job = get_last_completed_job(username)
            if (
                last_job
                and last_job.get("job_id") != st.session_state.last_loaded_job_id
            ):
                st.session_state.verification_results = last_job["results"]
                st.session_state.doc_name             = last_job["filename"]
                st.session_state.last_loaded_job_id   = last_job["job_id"]

            st.markdown("""
            <div class="glass-card">
              <h4 style="margin-top:0; color:#6ee7f7; font-weight:600;">How to use:</h4>
              <ol style="margin-bottom:0; padding-left:20px; font-size:0.95rem; line-height:1.6;">
                <li>Upload a scanned QAP PDF document using the file uploader below.</li>
                <li>Review the estimated processing time based on the file size and pages.</li>
                <li>Click <strong>🚀 Run Verification Pipeline</strong> — the job runs in the background.</li>
                <li>You can safely close the tab or log out. When you return, check <strong>My History</strong> for results.</li>
              </ol>
            </div>
            """, unsafe_allow_html=True)

            uploaded_file = st.file_uploader(
                "Upload scanned QAP document (PDF)",
                type=["pdf", "md"],
                key="user_pdf_uploader",
                help="Upload the scanned QAP PDF or a pre-converted Markdown (.md) file."
            )

            if uploaded_file:
                import uuid as _uuid
                _job_id   = str(_uuid.uuid4())
                _filename = uploaded_file.name

                # Save file to user's permanent uploads folder
                _save_path = get_upload_path(username, _job_id, _filename)
                _save_path.write_bytes(uploaded_file.getbuffer())

                is_pdf        = _save_path.suffix.lower() == ".pdf"
                checklist_len = len(st.session_state.checklist)
                est_seconds   = estimate_verification_time(_save_path, checklist_len, is_pdf)

                if est_seconds >= 60:
                    est_str = f"{est_seconds // 60} min {est_seconds % 60} sec"
                else:
                    est_str = f"{est_seconds} seconds"

                st.markdown(f"""
                <div style="background:rgba(59,130,246,0.1);border:1px solid rgba(59,130,246,0.25);
                            border-radius:10px;padding:12px 16px;margin-bottom:20px;">
                  <span style="font-size:1.05rem;">⏳ <strong>Estimated Analysis Time:</strong>
                    <span style="color:#6ee7f7;font-weight:700;">~{est_str}</span></span><br>
                  <span style="font-size:0.82rem;color:#94a3b8;">(Based on document format and
                    {checklist_len} verification rules)</span>
                </div>
                """, unsafe_allow_html=True)

                if st.button(
                    "🚀 Run Verification Pipeline",
                    use_container_width=True, type="primary", key="user_run_btn"
                ):
                    if is_pdf and not is_mineru_available():
                        st.error(
                            "MinerU is not installed. "
                            "Please convert the PDF to Markdown first and upload the `.md` file."
                        )
                    else:
                        # Create persistent job record (status: pending)
                        create_job_record(username, _filename, _job_id)

                        # Launch background thread with snapshotted settings
                        launch_verification_job(
                            username          = username,
                            job_id            = _job_id,
                            file_path         = _save_path,
                            checklist         = list(st.session_state.checklist),
                            selected_model    = st.session_state.selected_model,
                            selected_method   = st.session_state.selected_method,
                            enable_image_desc = st.session_state.enable_image_desc,
                            vision_model      = st.session_state.vision_model,
                            use_embeddings    = st.session_state.use_embeddings,
                            top_k             = st.session_state.top_k,
                        )

                        st.success(
                            "✅ **Verification job started in the background!** "
                            "You can safely close this tab or log out. "
                            "When you return, open **My History** to see your results."
                        )
                        st.info(
                            f"📄 Processing: `{_filename}`  "
                            f"\n🔑 Job ID: `{_job_id[:8]}…`"
                        )

            # ── Show last completed result (auto-loaded on login) ─────────
            if "verified" in st.session_state.get("verification_results", {}):
                ver_list = st.session_state.verification_results["verified"]
                st.markdown("---")
                _last = get_last_completed_job(username)
                if _last:
                    st.markdown(
                        f"""
                        <div style="background:rgba(52,211,153,0.08);border:1px solid rgba(52,211,153,0.2);
                                    border-radius:10px;padding:10px 16px;margin-bottom:1rem;">
                          <span style="color:#34d399;font-weight:600;">📋 Showing results for:</span>
                          <span style="color:#e2e8f0;"> {_last['filename']}</span>
                          <span style="color:#94a3b8;font-size:0.82rem;">&nbsp;·&nbsp;Completed {_last.get('completed_at','')}</span>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )
                _render_results_table(ver_list, st.session_state.doc_name, key_suffix="_main")

        # ══════════════════════════════════════════════════════════════════════
        #  TAB B — My History
        # ══════════════════════════════════════════════════════════════════════
        with TAB_HISTORY:
            st.markdown("### 📜 Your Verification History")
            st.caption("All documents you have submitted for verification. Click **View Results** to inspect a completed audit.")

            history = load_user_history(username)

            if not history:
                st.markdown("""
                <div class="glass-card" style="text-align:center;padding:2.5rem;">
                  <div style="font-size:2.5rem;margin-bottom:0.5rem;">📂</div>
                  <div style="color:#94a3b8;font-size:1rem;">No history yet. Upload a document and run verification to get started.</div>
                </div>
                """, unsafe_allow_html=True)
            else:
                # ── Clear All button ──────────────────────────────────────
                _, col_clr = st.columns([3, 1])
                with col_clr:
                    if st.button("🗑️ Clear All History", key="clear_all_history_btn", type="secondary"):
                        clear_all_history(username)
                        st.session_state.verification_results = {}
                        st.session_state.doc_name = ""
                        st.session_state.last_loaded_job_id = None
                        st.success("All history cleared.")
                        st.rerun()

                # ── Job cards (newest first) ──────────────────────────────
                for idx, job in enumerate(history):
                    job_id       = job.get("job_id", "?")
                    filename     = job.get("filename", "Unknown file")
                    status       = job.get("status", "unknown")
                    uploaded_at  = job.get("uploaded_at", "")
                    completed_at = job.get("completed_at", "")
                    err_msg      = job.get("error_message", "")

                    # Status badge HTML
                    if status == "completed":
                        badge_html = "<span style='background:rgba(52,211,153,0.15);color:#34d399;border:1px solid rgba(52,211,153,0.3);border-radius:20px;padding:2px 12px;font-size:0.8rem;font-weight:600;'>✅ Completed</span>"
                    elif status == "running":
                        badge_html = "<span style='background:rgba(251,191,36,0.15);color:#fbbf24;border:1px solid rgba(251,191,36,0.3);border-radius:20px;padding:2px 12px;font-size:0.8rem;font-weight:600;'>🔄 Running…</span>"
                    elif status == "pending":
                        badge_html = "<span style='background:rgba(99,179,237,0.15);color:#60a5fa;border:1px solid rgba(99,179,237,0.3);border-radius:20px;padding:2px 12px;font-size:0.8rem;font-weight:600;'>⏳ Pending</span>"
                    else:
                        badge_html = "<span style='background:rgba(248,113,113,0.15);color:#f87171;border:1px solid rgba(248,113,113,0.3);border-radius:20px;padding:2px 12px;font-size:0.8rem;font-weight:600;'>❌ Failed</span>"

                    completed_line = (
                        f"&nbsp;·&nbsp;<span style='font-size:0.78rem;color:#94a3b8;'>Completed: {completed_at}</span>"
                        if completed_at else ""
                    )

                    st.markdown(
                        f"""
                        <div class="glass-card" style="margin-bottom:0.5rem;">
                          <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;">
                            <div>
                              <span style="font-size:1rem;font-weight:600;color:#e2e8f0;">📄 {filename}</span><br>
                              <span style="font-size:0.78rem;color:#94a3b8;">Uploaded: {uploaded_at}</span>
                              {completed_line}
                            </div>
                            <div>{badge_html}</div>
                          </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    btn_c1, btn_c2, btn_c3 = st.columns([2, 1, 1])

                    with btn_c2:
                        if status == "completed" and job.get("results"):
                            if st.button(
                                "👁️ View Results",
                                key=f"view_job_{job_id}_{idx}",
                                use_container_width=True,
                            ):
                                st.session_state.verification_results = job["results"]
                                st.session_state.doc_name             = filename
                                st.session_state.last_loaded_job_id   = job_id
                                st.rerun()

                    with btn_c3:
                        if st.button(
                            "🗑️ Delete",
                            key=f"del_job_{job_id}_{idx}",
                            use_container_width=True,
                            type="secondary",
                        ):
                            delete_history_entry(username, job_id)
                            if st.session_state.last_loaded_job_id == job_id:
                                st.session_state.verification_results = {}
                                st.session_state.doc_name = ""
                                st.session_state.last_loaded_job_id = None
                            st.rerun()

                    # Error details
                    if status == "failed" and err_msg:
                        with st.expander("⚠️ Error details"):
                            st.code(err_msg[:2000], language="text")

                    # ── Inline results expander ───────────────────────────
                    if (
                        status == "completed"
                        and job.get("results")
                        and st.session_state.last_loaded_job_id == job_id
                    ):
                        with st.expander(f"📊 Results — {filename}", expanded=True):
                            _render_results_table(
                                st.session_state.verification_results.get("verified", []),
                                filename,
                                key_suffix=f"_hist_{job_id[:8]}_{idx}",
                            )

                    st.markdown(
                        "<hr style='border-color:rgba(255,255,255,0.06);margin:0.25rem 0;'>",
                        unsafe_allow_html=True,
                    )

        # ══════════════════════════════════════════════════════════════════════
        #  TAB C — Checklist Questions
        # ══════════════════════════════════════════════════════════════════════
        with TAB_QUESTIONS:
            st.markdown("### 📋 Checklist Questions")
            st.caption("Here are the verification questions currently defined in the checklist.")

            checklist = st.session_state.get("checklist", [])
            if not checklist:
                st.info("No questions in checklist.")
            else:
                q_rows = []
                for item in checklist:
                    q_rows.append({
                        "ID": item.get("id"),
                        "Section Name": item.get("section_name"),
                        "Verification Question": item.get("question"),
                    })
                df_q = pd.DataFrame(q_rows)
                st.dataframe(
                    df_q,
                    column_config={
                        "ID": st.column_config.NumberColumn("ID", width="small"),
                        "Section Name": st.column_config.TextColumn("Section Name", width="medium"),
                        "Verification Question": st.column_config.TextColumn("Verification Question", width="large"),
                    },
                    use_container_width=True,
                    hide_index=True,
                    key="checklist_questions_df"
                )


elif page_mode == "Admin Portal":
    if not st.session_state.admin_authenticated:
        # Display Admin Login Page
        st.markdown("<div class='hero-title'>🔐 Administrative Access</div>", unsafe_allow_html=True)
        st.markdown("<div class='hero-sub'>Verify credentials to configure checklist verification rules and inspect extraction data.</div>", unsafe_allow_html=True)
        
        # Center column login box
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("<br><br>", unsafe_allow_html=True)
            with st.form("admin_login_form"):
                st.markdown("<h3 style='margin-top:0; text-align:center; color:#3b82f6;'>Admin Authenticate</h3>", unsafe_allow_html=True)
                admin_id = st.text_input("Admin ID", placeholder="Enter administrative ID")
                admin_pwd = st.text_input("Password", type="password", placeholder="Enter Password")
                submitted = st.form_submit_button("Log In", use_container_width=True)
                
                if submitted:
                    if admin_id == "099866" and admin_pwd == "ai@099866":
                        st.session_state.admin_authenticated = True
                        st.success("Access granted! Loading Admin Panel...")
                        time.sleep(1)
                        st.rerun()
                    else:
                        st.error("Authentication failed: Invalid credentials.")
    else:
        # Admin Portal Core (originally from app.py)
        # Pull parameters from state
        selected_model = st.session_state.selected_model
        selected_method = st.session_state.selected_method
        enable_image_desc = st.session_state.enable_image_desc
        vision_model = st.session_state.vision_model
        use_embeddings = st.session_state.use_embeddings
        top_k = st.session_state.top_k
        mineru_ok = is_mineru_available()

        # Tabs
        TAB_UPLOAD, TAB_CHECKLIST, TAB_RESULTS, TAB_TREE, TAB_DEBUG = st.tabs([
            "📂 Upload & Process",
            "📋 Checklist",
            "📊 Verification Results",
            "🌳 Document Tree",
            "🔬 Debug",
        ])

        # ══════════════════════════════════════════════════════════════════════════════
        #  TAB 1 — Upload & Process
        # ══════════════════════════════════════════════════════════════════════════════
        with TAB_UPLOAD:
            col_up, col_stat = st.columns([1, 1], gap="large")

            with col_up:
                st.markdown("### 📄 Document Upload")
                uploaded = st.file_uploader(
                    "Upload QAP document",
                    type=["pdf", "md"],
                    help="Upload the scanned QAP PDF or a pre-converted MinerU Markdown (.md) file.",
                    key="admin_pdf_uploader"
                )

                if uploaded:
                    st.session_state.doc_name = uploaded.name
                    scratch = Path("temp")
                    scratch.mkdir(parents=True, exist_ok=True)
                    temp_path = scratch / uploaded.name
                    temp_path.write_bytes(uploaded.getbuffer())
                    st.success(f"Saved `{uploaded.name}` to workspace.")

                    if st.button("🚀 Parse Document & Extract Structure", use_container_width=True, type="primary", key="admin_parse_btn"):
                        with st.spinner("Parsing document… this may take a while for large scanned PDFs."):
                            try:
                                if temp_path.suffix.lower() == ".pdf":
                                    if not mineru_ok:
                                        st.error(
                                            "MinerU is not installed. "
                                            "Please convert the PDF to Markdown first and upload the `.md` file."
                                        )
                                        st.stop()
                                    out_dir = scratch / "mineru_out"
                                   
                                    md_content, md_file_path = convert_pdf_to_markdown(temp_path, out_dir, method=selected_method)
                                else:
                                    md_content = temp_path.read_text(encoding="utf-8", errors="replace")
                                    md_file_path = str(temp_path)

                                if enable_image_desc and vision_model:
                                    with st.spinner("Describing images using Vision LLM..."):
                                        from llm_verifier import process_markdown_images
                                        status_ph = st.empty()
                                        md_content = process_markdown_images(
                                            md_content=md_content,
                                            md_file_path=md_file_path,
                                            vision_model=vision_model,
                                            status_placeholder=status_ph
                                        )
                                        status_ph.empty()

                                result = extract_sections(md_content)
                                st.session_state.extraction_result    = result
                                st.session_state.verification_results = {}

                                n_flat   = len(result["flat"])
                                n_toc    = len(result["toc_entries"])
                                n_tables = len(result["table_nodes"])
                                n_figs   = len(result["figure_nodes"])

                                st.success(
                                    f"✅ Document parsed — "
                                    f"**{n_flat}** sections · "
                                    f"**{n_toc}** TOC entries · "
                                    f"**{n_tables}** tables · "
                                    f"**{n_figs}** figures"
                                )

                                if n_toc == 0:
                                    st.warning(
                                        "⚠️ No Table of Contents was detected. "
                                        "The section tree will be built from '#'-headings and plain numeric headings only. "
                                        "Results may be less accurate for documents with an unusual TOC format."
                                    )

                            except Exception as exc:
                                st.error(f"Processing failed: {exc}")
                                import traceback
                                st.code(traceback.format_exc())

            with col_stat:
                st.markdown("### 📊 Extraction Summary")
                res = st.session_state.extraction_result
                if res:
                    st.markdown(f"**File:** `{st.session_state.doc_name}`")
                    anchor = res.get("anchor")
                    st.markdown(f"**First numeric anchor:** `{anchor.text if anchor else 'None detected'}`")

                    c1, c2, c3, c4 = st.columns(4)
                    c1.metric("Sections",    len(res["flat"]))
                    c2.metric("TOC entries", len(res["toc_entries"]))
                    c3.metric("Tables",      len(res["table_nodes"]))
                    c4.metric("Figures",     len(res["figure_nodes"]))

                    with st.expander("Preview first 300 lines of parsed Markdown"):
                        st.code("\n".join(res["lines"][:300]), language="markdown")
                else:
                    st.info("Upload and parse a document to see the extraction summary here.")

        # ══════════════════════════════════════════════════════════════════════════════
        #  TAB 2 — Checklist
        # ══════════════════════════════════════════════════════════════════════════════
        with TAB_CHECKLIST:
            st.markdown("### 📋 Verification Checklist")
            st.caption("Edit checklist items below, import from JSON, or export.")

            ccol1, ccol2 = st.columns([1, 1])
            with ccol1:
                uploaded_cl = st.file_uploader("Import checklist (JSON)", type=["json"], key="admin_cl_upload")
                if uploaded_cl:
                    try:
                        imported = json.load(uploaded_cl)
                        if (isinstance(imported, list) and imported
                                and "section_name" in imported[0]):
                            st.session_state.checklist = imported
                            st.success("Checklist loaded!")
                        else:
                            st.error("Invalid format. Must be list of {id, section_name, question, prompt}.")
                    except Exception as e:
                        st.error(f"Parse error: {e}")

            with ccol2:
                st.download_button(
                    "📥 Export checklist (JSON)",
                    data=json.dumps(st.session_state.checklist, indent=2),
                    file_name="qap_checklist.json",
                    mime="application/json",
                    key="admin_cl_download"
                )

            st.markdown("---")
            edited_df = st.data_editor(
                pd.DataFrame(st.session_state.checklist),
                num_rows="dynamic",
                use_container_width=True,
                column_config={
                    "id":           st.column_config.NumberColumn("ID", width="small"),
                    "section_name": st.column_config.TextColumn("Section Name", width="medium"),
                    "question":     st.column_config.TextColumn("Verification Question", width="large"),
                    "prompt":       st.column_config.TextColumn("LLM Guideline / Prompt", width="large"),
                },
                key="admin_checklist_editor"
            )
            btn_col1, btn_col2 = st.columns([1, 1])
            with btn_col1:
                if st.button("💾 Save Checklist Changes", use_container_width=True, key="admin_save_checklist_btn"):
                    old_cl = {item["id"]: item for item in st.session_state.checklist}
                    new_cl = []
                    
                    with st.spinner("Generating prompts for new/updated items using Ollama (gpt-oss:20b)..."):
                        for row in edited_df.to_dict(orient="records"):
                            item_id = row.get("id")
                            sec_name = row.get("section_name", "")
                            if sec_name is None:
                                sec_name = ""
                            sec_name = str(sec_name).strip()

                            quest = row.get("question", "")
                            if quest is None:
                                quest = ""
                            quest = str(quest).strip()

                            curr_prompt = row.get("prompt", "")
                            if curr_prompt is None:
                                curr_prompt = ""
                            curr_prompt = str(curr_prompt).strip()
                            
                            needs_gen = False
                            if not curr_prompt:
                                needs_gen = True
                            elif item_id not in old_cl:
                                needs_gen = True
                            else:
                                old_item = old_cl[item_id]
                                if (old_item.get("section_name") != sec_name or old_item.get("question") != quest) and old_item.get("prompt") == curr_prompt:
                                    needs_gen = True
                                    
                            if needs_gen and sec_name and quest:
                                curr_prompt = generate_prompt_with_ollama(sec_name, quest, model_name="gpt-oss:20b")
                                
                            row["prompt"] = curr_prompt
                            new_cl.append(row)
                            
                    for idx, row in enumerate(new_cl, 1):
                        row["id"] = idx

                    st.session_state.checklist = new_cl
                    
                    try:
                        with open("qap_checklist.json", "w", encoding="utf-8") as f:
                            json.dump(new_cl, f, indent=2)
                        st.success("Checklist saved and prompts generated successfully! Updated qap_checklist.json.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Saved changes to session state, but failed to write to qap_checklist.json: {e}")
            
            with btn_col2:
                if st.button("🤖 Auto-Generate All Prompts via Ollama (gpt-oss:20b)", use_container_width=True, key="admin_autogen_all_prompts_btn"):
                    new_cl = []
                    prog_bar = st.progress(0.0)
                    status_text = st.empty()
                    
                    rows = edited_df.to_dict(orient="records")
                    for idx, row in enumerate(rows):
                        sec_name = row.get("section_name", "")
                        if sec_name is None:
                            sec_name = ""
                        sec_name = str(sec_name).strip()

                        quest = row.get("question", "")
                        if quest is None:
                            quest = ""
                        quest = str(quest).strip()
                        
                        if sec_name and quest:
                            status_text.markdown(f"🤖 Generating prompt for **{sec_name}** ({idx+1}/{len(rows)})...")
                            prog_bar.progress((idx + 1) / len(rows))
                            curr_prompt = generate_prompt_with_ollama(sec_name, quest, model_name="gpt-oss:20b")
                            row["prompt"] = curr_prompt
                        
                        new_cl.append(row)
                        
                    for idx, row in enumerate(new_cl, 1):
                        row["id"] = idx
                        
                    st.session_state.checklist = new_cl
                    prog_bar.progress(1.0)
                    status_text.empty()
                    
                    try:
                        with open("qap_checklist.json", "w", encoding="utf-8") as f:
                            json.dump(new_cl, f, indent=2)
                        st.success("Successfully generated prompts for all checklist items using gpt-oss:20b and saved to qap_checklist.json!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Generated prompts, but failed to write to qap_checklist.json: {e}")

        # ══════════════════════════════════════════════════════════════════════════════
        #  TAB 3 — Verification Results
        # ══════════════════════════════════════════════════════════════════════════════
        with TAB_RESULTS:
            st.markdown("### 📊 QAP Verification Dashboard")

            if not st.session_state.extraction_result:
                st.warning("Please upload and parse a document first (Upload & Process tab).")
            else:
                res      = st.session_state.extraction_result
                flat     = res["flat"]
                tbls     = res["table_nodes"]
                figs     = res["figure_nodes"]
                checklist = st.session_state.checklist

                if st.button("▶️ Run Full Verification Pipeline", use_container_width=True, type="primary", key="admin_run_verification_btn"):
                    with st.spinner("Mapping checklist items to document sections…"):
                        mapped = match_checklist_to_sections(
                            checklist       = checklist,
                            all_nodes       = flat,
                            table_nodes     = tbls,
                            figure_nodes    = figs,
                            top_k           = top_k,
                            use_embeddings  = use_embeddings,
                            ollama_base_url = "http://172.27.30.222:12000",
                        )
                        st.success("Section mapping complete.")

                    with st.spinner(f"Verifying {len(mapped)} checklist items via {selected_model}…"):
                        llm_results = []
                        prog = st.progress(0.0)
                        status_txt = st.empty()

                        for idx, m in enumerate(mapped):
                            status_txt.markdown(
                                f"Verifying **{m['checklist_section']}** "
                                f"({idx+1}/{len(mapped)})…"
                            )
                            prog.progress((idx + 1) / len(mapped))

                            ver = verify_checklist_item(
                                model_name        = selected_model,
                                checklist_section = m["checklist_section"],
                                question          = m["question"],
                                prompt_guideline  = m["prompt"],
                                matched_sections  = m["tree_matches"],
                                table_matches     = m["table_matches"],
                                figure_matches    = m["figure_matches"],
                            )

                            llm_results.append({
                                **m,
                                "llm_status":   ver.get("status", "Not Found"),
                                "llm_summary":  ver.get("summary", ""),
                                "llm_evidence": ver.get("evidence", ""),
                                "llm_gaps":     ver.get("gaps", ""),
                            })

                        status_txt.empty()
                        st.session_state.verification_results = {"verified": llm_results}
                        st.success("🎉 Verification complete!")

                if "verified" in st.session_state.verification_results:
                    ver_list = st.session_state.verification_results["verified"]

                    total    = len(ver_list)
                    verified = sum(1 for x in ver_list if x["llm_status"] == "Verified")
                    partial  = sum(1 for x in ver_list if x["llm_status"] == "Partially Verified")
                    missing  = sum(1 for x in ver_list if x["llm_status"] in ("Not Found", "Failed Verification"))

                    mc1, mc2, mc3, mc4 = st.columns(4)
                    mc1.metric("Total Rules",      total)
                    mc2.metric("✅ Verified",      verified, delta=f"{verified/total*100:.0f}%")
                    mc3.metric("⚠️ Partial",       partial,  delta=f"{partial/total*100:.0f}%")
                    mc4.metric("❌ Missing/Failed",missing,  delta=f"-{missing/total*100:.0f}%")

                    rpt = [
                        f"# QAP Audit Report — {st.session_state.doc_name}\n",
                        f"**Summary:** {verified}/{total} items verified.\n",
                        "| ID | Section | Status | Best Match |\n|---|---|---|---|",
                    ]
                    for r in ver_list:
                        best_hdg = r["tree_matches"][0]["matched_heading"] if r["tree_matches"] else "—"
                        rpt.append(f"| {r['checklist_id']} | {r['checklist_section']} | {r['llm_status']} | {best_hdg} |")
                    rpt.append("\n## Detailed Findings\n")
                    for r in ver_list:
                        rpt.append(f"### {r['checklist_id']}. {r['checklist_section']}")
                        rpt.append(f"- **Status:** {r['llm_status']}")
                        rpt.append(f"- **Summary:** {r['llm_summary']}")
                        rpt.append(f"- **Evidence:** {r['llm_evidence']}")
                        rpt.append(f"- **Gaps:** {r['llm_gaps']}\n")

                    st.download_button(
                        "📥 Download Audit Report (Markdown)",
                        data="\n".join(rpt),
                        file_name="qap_audit_report.md",
                        mime="text/markdown",
                        key="admin_report_download"
                    )

                    st.markdown("---")

                    for r in ver_list:
                        status = r["llm_status"]
                        badge_cls = {
                            "Verified":            "badge-verified",
                            "Partially Verified":  "badge-partial",
                            "Not Found":           "badge-missing",
                        }.get(status, "badge-error")

                        best_hdg = r["tree_matches"][0]["matched_heading"] if r["tree_matches"] else "—"
                        best_scr = r["tree_matches"][0]["score"]           if r["tree_matches"] else 0.0
                        best_tier = r["tree_matches"][0]["match_tier"]     if r["tree_matches"] else "—"

                        st.markdown(f"""
        <div class="glass-card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <h4 style="margin:0;font-weight:600;">{r['checklist_id']}. {r['checklist_section']}</h4>
            <span class="badge {badge_cls}">{status}</span>
          </div>
          <p style="font-size:0.92rem;margin:4px 0;">
            <strong>Question:</strong> {r['question']}
          </p>
          <p style="font-size:0.87rem;margin:4px 0;color:#94a3b8;">
            <strong>Best section match:</strong> <code>{best_hdg}</code>
            &nbsp;{_tier_chip(best_tier)}&nbsp;
            <strong>score:</strong> {best_scr:.3f}
          </p>
        </div>""", unsafe_allow_html=True)

                        with st.expander(f"▸ Findings & Evidence — {r['checklist_section']}"):
                            fcol1, fcol2 = st.columns([1, 1])
                            with fcol1:
                                st.write("**🔎 LLM Summary**")
                                st.write(r["llm_summary"] or "—")
                                st.write("**📌 Evidence**")
                                st.info(r["llm_evidence"] or "—")
                                st.write("**⚠️ Gaps / Recommendations**")
                                st.warning(r["llm_gaps"] or "—")
                            with fcol2:
                                if r["tree_matches"]:
                                    st.write("**📁 Section Matches**")
                                    for m in r["tree_matches"]:
                                        with st.container():
                                            st.write(
                                                f"**#{m['rank']}** `{m['matched_heading']}` "
                                                f"{_tier_chip(m['match_tier'])} **{m['score']:.3f}**",
                                                unsafe_allow_html=True,
                                            )

                                if r["table_matches"]:
                                    st.write("**📋 Table Matches**")
                                    for m in r["table_matches"]:
                                        with st.container():
                                            st.write(
                                                f"**#{m['rank']}** `{m['table_title']}` "
                                                f"{_tier_chip(m['match_tier'])} **{m['score']:.3f}**",
                                                unsafe_allow_html=True,
                                            )

                                if r["figure_matches"]:
                                    st.write("**🖼️ Figure Matches**")
                                    for m in r["figure_matches"]:
                                        with st.container():
                                            st.write(
                                                f"**#{m['rank']}** `{m['caption']}` "
                                                f"{_tier_chip(m['match_tier'])} **{m['score']:.3f}**",
                                                unsafe_allow_html=True,
                                            )

        # ══════════════════════════════════════════════════════════════════════════════
        #  TAB 4 — Document Tree
        # ══════════════════════════════════════════════════════════════════════════════
        with TAB_TREE:
            st.markdown("### 🌳 Document Structural Hierarchy")

            res = st.session_state.extraction_result
            if not res:
                st.info("Parse a document first to view its section tree.")
            else:
                tree_tab, tbl_tab, fig_tab = st.tabs(["📖 Section Tree", "📋 Table Tree", "🖼️ Figure Tree"])

                with tree_tab:
                    preamble = res.get("preamble", [])
                    if preamble:
                        st.markdown("#### Front-matter / Preamble")
                        for node in preamble:
                            src_lbl = f"[{node.heading.source}]"
                            with st.expander(
                                f"📄 {src_lbl} {node.label}  "
                                f"(lines {node.start_line}–{node.end_line})"
                            ):
                                st.code(node.own_content[:5000], language="markdown")

                    tree = res.get("tree", [])
                    if tree:
                        st.markdown("#### Numbered Section Tree")

                        def render_node(node: SectionNode, depth: int = 0) -> None:
                            indent = "&nbsp;" * depth * 4
                            num    = f"[{node.numeric_prefix}]" if node.numeric_prefix else "[—]"
                            lines_info = f"lines {node.start_line}–{node.end_line}"

                            with st.expander(f"{'  '*depth}{num} {node.label}  ({lines_info})"):
                                st.caption(
                                    f"Source: {node.heading.source} | "
                                    f"Children: {len(node.children)} | "
                                    f"Content size: {len(node.content):,} chars"
                                )
                                t1, t2 = st.tabs(["Own Content", "Full Content (incl. children)"])
                                with t1:
                                    st.code(
                                        node.own_content[:8000]
                                        + ("…" if len(node.own_content) > 8000 else ""),
                                        language="markdown",
                                    )
                                with t2:
                                    st.code(
                                        node.content[:15000]
                                        + ("…" if len(node.content) > 15000 else ""),
                                        language="markdown",
                                    )
                                for child in node.children:
                                    render_node(child, depth + 1)

                        for root in tree:
                            render_node(root)
                    else:
                        st.warning("No numbered section tree could be built. Check the Debug tab for the master heading list.")

                with tbl_tab:
                    table_nodes = res.get("table_nodes", [])
                    st.markdown(f"#### {len(table_nodes)} Table(s) extracted")
                    if not table_nodes:
                        st.info("No tables were found in the document.")
                    for i, tbl in enumerate(table_nodes, 1):
                        sect_info = f" | Section: {tbl.section_heading}" if getattr(tbl, "section_heading", None) else ""
                        with st.expander(f"📋 Table {i}: {tbl.title}  (lines {tbl.start_line}–{tbl.end_line}){sect_info}"):
                            st.markdown("**Cell text:**")
                            st.code(tbl.cell_text[:5000], language="text")
                            with st.expander("Raw HTML"):
                                st.code(tbl.html[:3000], language="html")

                with fig_tab:
                    figure_nodes = res.get("figure_nodes", [])
                    st.markdown(f"#### {len(figure_nodes)} Figure(s) / Image(s) extracted")
                    if not figure_nodes:
                        st.info("No figures/images were found in the document.")
                    for i, fig in enumerate(figure_nodes, 1):
                        with st.expander(f"🖼️ Figure {i}: {fig.caption}  (line {fig.line_num})"):
                            st.markdown(f"**Ref:** `{fig.ref}`")
                            st.markdown("**Context lines:**")
                            st.code(fig.context, language="markdown")

        # ══════════════════════════════════════════════════════════════════════════════
        #  TAB 5 — Debug
        # ══════════════════════════════════════════════════════════════════════════════
        with TAB_DEBUG:
            st.markdown("### 🔬 Raw Extraction Debug View")

            res = st.session_state.extraction_result
            if not res:
                st.info("Parse a document first.")
            else:
                with st.expander(f"📑 TOC Entries ({len(res['toc_entries'])})"):
                    if res["toc_entries"]:
                        df_toc = pd.DataFrame(res["toc_entries"])
                        st.dataframe(df_toc, use_container_width=True)
                    else:
                        st.warning("No TOC entries detected.")

                flat = res["flat"]
                pre  = res["preamble"]
                all_nodes_flat: list[SectionNode] = pre + flat

                heading_rows = []
                for node in all_nodes_flat:
                    heading_rows.append({
                        "line_num":  node.heading.line_num,
                        "text":      node.heading.text,
                        "numeric":   node.heading.numeric or "—",
                        "level":     node.heading.level,
                        "source":    node.heading.source,
                        "is_special":node.heading.is_special,
                    })
                heading_rows.sort(key=lambda x: x["line_num"])

                with st.expander(f"📝 All Detected Headings ({len(heading_rows)}) — sorted by line number"):
                    if heading_rows:
                        st.dataframe(pd.DataFrame(heading_rows), use_container_width=True)
                    else:
                        st.warning("No headings detected.")

                anchor = res.get("anchor")
                st.info(
                    f"**First Numeric Anchor:** "
                    f"`{anchor.text}` at line {anchor.line_num} (source: {anchor.source})"
                    if anchor else "**No numeric anchor detected.**"
                )

                with st.expander("📄 Raw cleaned Markdown (first 500 lines)"):
                    lines = res["lines"]
                    numbered = "\n".join(f"{i:>5}: {l}" for i, l in enumerate(lines[:500]))
                    st.code(numbered, language="text")
