"""
auth.py
=======
Authentication helpers and per-user history management for QAP Verification App.

User credentials are stored in users_config.json (easily replaceable).
Per-user history is stored in user_data/<username>/history.json.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
#  Constants
# ─────────────────────────────────────────────────────────────────────────────
USERS_CONFIG_PATH = Path("users_config.json")
USER_DATA_ROOT    = Path("user_data")


# ─────────────────────────────────────────────────────────────────────────────
#  Password Helpers
# ─────────────────────────────────────────────────────────────────────────────
def hash_password(password: str) -> str:
    """Return SHA-256 hex digest of a plain-text password."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def _check_password(plain: str, stored: dict) -> bool:
    """
    Compare a plain-text password against a stored user record.
    Supports both 'password_hash' (preferred) and 'password' (plain) fields.
    """
    if "password_hash" in stored:
        return hash_password(plain) == stored["password_hash"]
    elif "password" in stored:
        return plain == stored["password"]
    return False


# ─────────────────────────────────────────────────────────────────────────────
#  User Loading
# ─────────────────────────────────────────────────────────────────────────────
def load_users() -> list[dict]:
    """Load user records from users_config.json. Returns empty list on error."""
    if not USERS_CONFIG_PATH.exists():
        return []
    try:
        with open(USERS_CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("users", [])
    except Exception:
        return []


def verify_credentials(username: str, password: str) -> bool:
    """Return True if username + password match a user in users_config.json."""
    users = load_users()
    for user in users:
        if user.get("username", "").lower() == username.strip().lower():
            return _check_password(password, user)
    return False


# ─────────────────────────────────────────────────────────────────────────────
#  User Data Directory
# ─────────────────────────────────────────────────────────────────────────────
def get_user_dir(username: str) -> Path:
    """Return (and create) the per-user data directory."""
    user_dir = USER_DATA_ROOT / username
    user_dir.mkdir(parents=True, exist_ok=True)
    (user_dir / "uploads").mkdir(exist_ok=True)
    return user_dir


def get_history_path(username: str) -> Path:
    return get_user_dir(username) / "history.json"


# ─────────────────────────────────────────────────────────────────────────────
#  History CRUD
# ─────────────────────────────────────────────────────────────────────────────
def load_user_history(username: str) -> list[dict]:
    """Load all job records for a user. Returns [] if none exist."""
    path = get_history_path(username)
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save_history(username: str, records: list[dict]) -> None:
    """Atomically write the history list to disk (write-then-rename)."""
    path = get_history_path(username)
    tmp  = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, default=str)
    os.replace(tmp, path)


def create_job_record(username: str, filename: str, job_id: Optional[str] = None) -> dict:
    """
    Create a new pending job record, append to history, and return it.
    """
    job_id = job_id or str(uuid.uuid4())
    record = {
        "job_id":       job_id,
        "filename":     filename,
        "uploaded_at":  datetime.now().isoformat(timespec="seconds"),
        "status":       "pending",      # pending | running | completed | failed
        "completed_at": None,
        "error_message": None,
        "results":      None,           # full verification_results dict when done
    }
    records = load_user_history(username)
    records.insert(0, record)           # newest first
    _save_history(username, records)
    return record


def update_job_status(
    username:     str,
    job_id:       str,
    status:       str,
    results:      Optional[dict] = None,
    error_message: Optional[str] = None,
) -> None:
    """Update an existing job record in the user's history."""
    records = load_user_history(username)
    for rec in records:
        if rec["job_id"] == job_id:
            rec["status"] = status
            if results is not None:
                rec["results"] = results
            if error_message is not None:
                rec["error_message"] = error_message
            if status in ("completed", "failed"):
                rec["completed_at"] = datetime.now().isoformat(timespec="seconds")
            break
    _save_history(username, records)


def delete_history_entry(username: str, job_id: str) -> None:
    """Remove a single job record from the user's history."""
    records = load_user_history(username)
    records = [r for r in records if r["job_id"] != job_id]
    _save_history(username, records)


def clear_all_history(username: str) -> None:
    """Delete all job records for the user."""
    _save_history(username, [])


def get_last_completed_job(username: str) -> Optional[dict]:
    """Return the most recent completed job, or None."""
    for rec in load_user_history(username):
        if rec.get("status") == "completed" and rec.get("results"):
            return rec
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  Upload Path Helper
# ─────────────────────────────────────────────────────────────────────────────
def get_upload_path(username: str, job_id: str, filename: str) -> Path:
    """Return the full path where the uploaded file should be stored."""
    user_dir = get_user_dir(username)
    return user_dir / "uploads" / f"{job_id}_{filename}"


# ─────────────────────────────────────────────────────────────────────────────
#  Utility: generate hashes for real users (run standalone to hash passwords)
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        for pwd in sys.argv[1:]:
            print(f"{pwd!r}  →  {hash_password(pwd)}")
    else:
        print("Usage: python auth.py <password1> <password2> ...")
        print("This will print SHA-256 hashes you can paste into users_config.json as 'password_hash' values.")
