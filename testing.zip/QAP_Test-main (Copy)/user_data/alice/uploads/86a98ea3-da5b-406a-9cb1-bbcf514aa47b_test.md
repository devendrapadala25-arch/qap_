# 1.1 SCOPE

It describes Quality Assurance Plan of the Synthesized S-Band 2Watt Transmitter which is used in SAAW Project.

# 1.2 DESCRIPTION AND BLOCK DIAGRAM

The S-Band 2Watt Transmitter mainly consists of Synthesizer, Power Supply, Power Amplifier Section followed by Power Divider Section.

The PLL synthesizer circuit consists of VCO, RF synthesizer, a TCXO reference oscillator and modulation input circuit. The VCO is tuned in such a way that to cover the required frequency band (2200MHz to 2300MHz) and to meet the FM modulation requirements in the operating temperature range.


# 16 QA Matrix

Here is the QA Matrix table...
