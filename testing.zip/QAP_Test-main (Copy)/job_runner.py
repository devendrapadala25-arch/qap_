"""
job_runner.py
=============
Background thread runner for the QAP verification pipeline.

When a user clicks "Run Verification", a daemon thread is spawned here.
The thread executes the full 4-step pipeline (convert → extract → match → verify)
and writes status updates + final results to the user's history.json.
The Streamlit UI is completely decoupled — users can close the tab at any time.
"""

from __future__ import annotations

import threading
import traceback
from pathlib import Path
from typing import Any

from auth import update_job_status

# ─────────────────────────────────────────────────────────────────────────────
#  Global job registry — tracks threads so we can check liveness in the UI
# ─────────────────────────────────────────────────────────────────────────────
_lock: threading.Lock = threading.Lock()
ACTIVE_JOBS: dict[str, threading.Thread] = {}   # job_id → Thread


def is_job_running(job_id: str) -> bool:
    """Return True if the background thread for this job is still alive."""
    with _lock:
        t = ACTIVE_JOBS.get(job_id)
    return t is not None and t.is_alive()


def _cleanup_job(job_id: str) -> None:
    with _lock:
        ACTIVE_JOBS.pop(job_id, None)


# ─────────────────────────────────────────────────────────────────────────────
#  Core pipeline (mirrors the 4-step flow in app.py)
# ─────────────────────────────────────────────────────────────────────────────
def _pipeline(
    username:    str,
    job_id:      str,
    file_path:   Path,
    checklist:   list[dict],
    selected_model:     str,
    selected_method:    str,
    enable_image_desc:  bool,
    vision_model:       Any,
    use_embeddings:     bool,
    top_k:              int,
    ollama_base_url:    str,
) -> None:
    """
    Full 4-step verification pipeline that runs in a background thread.
    Writes status updates to history.json at each stage.
    """
    try:
        # Mark as running
        update_job_status(username, job_id, "running")

        # ── Import here to avoid circular issues ──────────────────────────
        from pdf_converter    import convert_pdf_to_markdown, is_mineru_available
        from section_extractor import extract_sections
        from section_matcher  import match_checklist_to_sections
        from llm_verifier     import verify_checklist_item

        is_pdf = file_path.suffix.lower() == ".pdf"
        scratch = file_path.parent

        # ── Step 1: PDF → Markdown conversion ────────────────────────────
        if is_pdf:
            out_dir = scratch / "mineru_out"
            md_content, md_file_path = convert_pdf_to_markdown(
                file_path, out_dir, method=selected_method
            )
        else:
            md_content  = file_path.read_text(encoding="utf-8", errors="replace")
            md_file_path = str(file_path)

        # ── Step 1.5: Optional image description via Vision LLM ──────────
        if enable_image_desc and vision_model:
            from llm_verifier import process_markdown_images
            md_content = process_markdown_images(
                md_content=md_content,
                md_file_path=md_file_path,
                vision_model=vision_model,
                status_placeholder=None,    # no UI placeholder in background
            )

        # ── Step 2: Section extraction ────────────────────────────────────
        result = extract_sections(md_content)
        flat   = result["flat"]
        tbls   = result["table_nodes"]
        figs   = result["figure_nodes"]

        # ── Step 3: Checklist matching ────────────────────────────────────
        mapped = match_checklist_to_sections(
            checklist      = checklist,
            all_nodes      = flat,
            table_nodes    = tbls,
            figure_nodes   = figs,
            top_k          = top_k,
            use_embeddings = use_embeddings,
            ollama_base_url= ollama_base_url,
        )

        # ── Step 4: LLM verification ──────────────────────────────────────
        llm_results = []
        for m in mapped:
            ver = verify_checklist_item(
                model_name        = selected_model,
                checklist_section = m["checklist_section"],
                question          = m["question"],
                prompt_guideline  = m["prompt"],
                matched_sections  = m["tree_matches"],
                table_matches     = m["table_matches"],
                figure_matches    = m["figure_matches"],
            )
            llm_results.append({
                **m,
                "llm_status":   ver.get("status",   "Not Found"),
                "llm_summary":  ver.get("summary",  ""),
                "llm_evidence": ver.get("evidence", ""),
                "llm_gaps":     ver.get("gaps",     ""),
            })

        # ── Save completed results ────────────────────────────────────────
        update_job_status(
            username  = username,
            job_id    = job_id,
            status    = "completed",
            results   = {"verified": llm_results},
        )

    except Exception as exc:
        update_job_status(
            username      = username,
            job_id        = job_id,
            status        = "failed",
            error_message = f"{type(exc).__name__}: {exc}\n\n{traceback.format_exc()}",
        )
    finally:
        _cleanup_job(job_id)


# ─────────────────────────────────────────────────────────────────────────────
#  Public API: launch a background job
# ─────────────────────────────────────────────────────────────────────────────
def launch_verification_job(
    username:           str,
    job_id:             str,
    file_path:          Path,
    checklist:          list[dict],
    selected_model:     str,
    selected_method:    str,
    enable_image_desc:  bool,
    vision_model:       Any,
    use_embeddings:     bool,
    top_k:              int,
    ollama_base_url:    str = "http://172.27.30.222:12000",
) -> threading.Thread:
    """
    Spawn a daemon thread to run the full pipeline in the background.
    Returns the Thread object (also stored in ACTIVE_JOBS).
    """
    thread = threading.Thread(
        target   = _pipeline,
        kwargs   = dict(
            username          = username,
            job_id            = job_id,
            file_path         = file_path,
            checklist         = checklist,
            selected_model    = selected_model,
            selected_method   = selected_method,
            enable_image_desc = enable_image_desc,
            vision_model      = vision_model,
            use_embeddings    = use_embeddings,
            top_k             = top_k,
            ollama_base_url   = ollama_base_url,
        ),
        daemon   = True,    # thread dies with the process, no zombie threads
        name     = f"qap-job-{job_id[:8]}",
    )
    with _lock:
        ACTIVE_JOBS[job_id] = thread
    thread.start()
    return thread
