"""
llm_verifier.py  (v2)
======================
Verifies QAP checklist items using a local Ollama LLM.
Sends matched section / table / figure content as context.
"""

from __future__ import annotations

import json
import logging
import requests
import re
import base64
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

OLLAMA_BASE_URL = "http://172.27.30.222:12000"
LLM_TIMEOUT     = 180   # seconds – generous for large-context requests


def get_available_ollama_models(base_url: str = OLLAMA_BASE_URL) -> list[str]:
    """Return list of model names installed in local Ollama."""
    try:
        resp = requests.get(f"{base_url}/api/tags", timeout=5)
        resp.raise_for_status()
        return sorted(m["name"] for m in resp.json().get("models", []))
    except Exception as exc:
        logger.warning(f"Failed to fetch Ollama models: {exc}")
        return []


def _build_context(
    tree_matches:   list[dict],
    table_matches:  list[dict],
    figure_matches: list[dict],
) -> str:
    """Assemble context text from all three match sources."""
    blocks: list[str] = []

    for idx, m in enumerate(tree_matches, 1):
        heading = m.get("matched_heading", "Unknown")
        content = m.get("content", "")[:12000]
        if len(m.get("content", "")) > 12000:
            content += "\n[… content truncated …]"
        blocks.append(f"=== SECTION MATCH #{idx}: {heading} ===\n{content}")

    for idx, m in enumerate(table_matches, 1):
        title   = m.get("table_title", "Table")
        content = m.get("content", "")[:4000]
        blocks.append(f"=== TABLE MATCH #{idx}: {title} ===\n{content}")

    for idx, m in enumerate(figure_matches, 1):
        caption = m.get("caption", "Figure")
        context = m.get("context", "")[:2000]
        blocks.append(f"=== FIGURE/IMAGE MATCH #{idx}: {caption} ===\n{context}")

    return "\n\n".join(blocks)


def verify_checklist_item(
    model_name:       str,
    checklist_section: str,
    question:         str,
    prompt_guideline: str,
    matched_sections: list[dict],           # tree_matches (legacy compat)
    table_matches:    list[dict] = None,
    figure_matches:   list[dict] = None,
    base_url:         str = OLLAMA_BASE_URL,
) -> dict[str, Any]:
    """
    Verify a single checklist item using the Ollama LLM.

    Returns dict with keys: status, summary, evidence, gaps.
    """
    table_matches  = table_matches  or []
    figure_matches = figure_matches or []

    context = _build_context(matched_sections, table_matches, figure_matches)

    system_prompt = (
        "You are an expert Quality Assurance Auditor for defence electronics documents.\n"
        "Verify if a QAP/QT/AT document meets a specific checklist requirement.\n"
        "Base your answer ONLY on the provided context. If information is absent, say so.\n"
        "Respond with ONLY a raw JSON object (no markdown, no code fences) matching:\n"
        "{\n"
        '  "status": "Verified" | "Partially Verified" | "Not Found" | "Failed Verification",\n'
        '  "summary": "concise summary",\n'
        '  "evidence": "specific quotes / values from context",\n'
        '  "gaps": "missing details or non-conformances"\n'
        "}"
    )

    user_msg = (
        f"CHECKLIST REQUIREMENT\n"
        f"Section: {checklist_section}\n"
        f"Question: {question}\n"
        f"Guideline: {prompt_guideline}\n\n"
        f"DOCUMENT CONTEXT\n"
        f"{context}\n\n"
        "Respond ONLY with the JSON object."
    )

    try:
        payload = {
            "model":   model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_msg},
            ],
            "options": {"temperature": 0.0},
            "format":  "json",
            "stream":  False,
        }
        resp = requests.post(
            f"{base_url}/api/chat", json=payload, timeout=LLM_TIMEOUT
        )
        resp.raise_for_status()
        raw = resp.json()["message"]["content"].strip()
        parsed = json.loads(raw)
        for key in ("status", "summary", "evidence", "gaps"):
            if key not in parsed:
                parsed[key] = "N/A"
        return parsed

    except Exception as exc:
        logger.error(f"LLM verification error: {exc}")
        return {
            "status":   "Failed Verification",
            "summary":  f"LLM error ({model_name}): {str(exc)}",
            "evidence": "",
            "gaps":     "Unable to verify due to internal error.",
        }


def describe_image(image_path: Path, model_name: str, base_url: str = OLLAMA_BASE_URL) -> str:
    """Describe an image using Ollama's multimodal/vision capabilities."""
    if not image_path.exists():
        logger.warning(f"Image path does not exist: {image_path}")
        return ""
    
    try:
        # Read and encode image to base64
        with open(image_path, "rb") as img_file:
            img_base64 = base64.b64encode(img_file.read()).decode("utf-8")
        
        system_prompt = (
            "You are an expert technical QA auditor for defence and electronics documentation.\n"
            "Analyze the provided diagram or image from a Quality Assurance Plan (QAP).\n"
            "Explain exactly what this diagram illustrates (e.g., flow chart, block diagram, schematic, table).\n"
            "Identify and list all blocks, process steps, input/output signals, hardware interfaces, or values shown.\n"
            "Be detailed, precise, and professional. Write a structured text summary."
        )
        
        user_msg = "Please analyze and describe this diagram/image in detail."
        
        payload = {
            "model": model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": user_msg,
                    "images": [img_base64]
                }
            ],
            "options": {"temperature": 0.1},
            "stream": False,
        }
        
        resp = requests.post(f"{base_url}/api/chat", json=payload, timeout=120)
        resp.raise_for_status()
        desc = resp.json()["message"]["content"].strip()
        return desc
    except Exception as e:
        logger.error(f"Failed to describe image {image_path} with {model_name}: {e}")
        return f"[Image analysis failed: {str(e)}]"


def process_markdown_images(
    md_content: str,
    md_file_path: str,
    vision_model: str,
    base_url: str = OLLAMA_BASE_URL,
    status_placeholder = None,
) -> str:
    """
    Find all image tags in md_content, describe them using vision_model,
    and append descriptions to the markdown file text.
    """
    md_file = Path(md_file_path)
    md_dir = md_file.parent
    
    # Regex matching markdown image: ![caption](path)
    # E.g. ![](images/abc.jpg)
    img_re = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
    img_matches = list(img_re.finditer(md_content))
    if not img_matches:
        return md_content
        
    logger.info(f"Found {len(img_matches)} images in markdown.")
    
    count = [0]
    total = len(img_matches)
    
    def replace_img(match):
        caption = match.group(1).strip()
        ref = match.group(2).strip()
        
        img_path = md_dir / ref
        count[0] += 1
        
        if img_path.exists():
            if status_placeholder:
                status_placeholder.markdown(f"🖼️ Describing image {count[0]}/{total}: `{ref}`...")
            
            desc = describe_image(img_path, vision_model, base_url)
            if desc:
                return f"{match.group(0)}\n\n**[Image Description ({ref}):**\n{desc}\n**]**\n\n"
        
        return match.group(0)

    processed_md = img_re.sub(replace_img, md_content)
    return processed_md
