"""
auth.py
=======
Authentication helpers and per-user history management for QAP Verification App.

User credentials are stored in users_config.json (easily replaceable).
Per-user history is stored in user_data/<username>/history.json.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
#  Constants
# ─────────────────────────────────────────────────────────────────────────────
USERS_CONFIG_PATH = Path("users_config.json")
LDAP_CONFIG_PATH  = Path("ldap_config.json")
USER_DATA_ROOT    = Path("user_data")


# ─────────────────────────────────────────────────────────────────────────────
#  Password Helpers
# ─────────────────────────────────────────────────────────────────────────────
def hash_password(password: str) -> str:
    """Return SHA-256 hex digest of a plain-text password."""
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def _check_password(plain: str, stored: dict) -> bool:
    """
    Compare a plain-text password against a stored user record.
    Supports both 'password_hash' (preferred) and 'password' (plain) fields.
    """
    if "password_hash" in stored:
        return hash_password(plain) == stored["password_hash"]
    elif "password" in stored:
        return plain == stored["password"]
    return False


# ─────────────────────────────────────────────────────────────────────────────
#  LDAP Configuration & Authentication
# ─────────────────────────────────────────────────────────────────────────────
def load_ldap_config() -> dict:
    """Load LDAP connection settings from ldap_config.json."""
    if not LDAP_CONFIG_PATH.exists():
        return {"ldap_enabled": False}
    try:
        with open(LDAP_CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"ldap_enabled": False}


def authenticate_ldap(username: str, password: str, config: Optional[dict] = None) -> tuple[bool, str]:
    """
    Authenticate a user against the configured LDAP server using ldap3.
    Supports direct_bind and search_bind modes.
    Returns (success_bool, message_detail).
    """
    if config is None:
        config = load_ldap_config()

    if not config.get("ldap_enabled", False):
        return False, "LDAP authentication is disabled."

    username_clean = username.strip()
    if not username_clean or not password:
        return False, "Username and password are required."

    try:
        import ldap3
        from ldap3.core.exceptions import LDAPException
    except ImportError:
        return False, "ldap3 library is not installed. Please run: pip install ldap3"

    server_uri = config.get("server_uri", "ldap://localhost:389")
    use_ssl = config.get("use_ssl", False)
    use_start_tls = config.get("use_start_tls", False)
    timeout = config.get("timeout_seconds", 5)
    bind_method = config.get("bind_method", "direct_bind")

    try:
        server = ldap3.Server(server_uri, use_ssl=use_ssl, connect_timeout=timeout)

        # ── Direct Bind Mode ──────────────────────────────────────────────────
        if bind_method == "direct_bind":
            template = config.get("user_dn_template", "uid={username},ou=users,dc=example,dc=com")
            user_dn = template.format(username=username_clean)

            conn = ldap3.Connection(
                server,
                user=user_dn,
                password=password,
                auto_bind=False,
                receive_timeout=timeout,
            )
            if use_start_tls:
                conn.open()
                conn.start_tls()

            if conn.bind():
                conn.unbind()
                return True, f"Successfully authenticated '{username_clean}' via LDAP direct bind."
            else:
                last_error = conn.result.get("description", "Invalid credentials")
                return False, f"LDAP direct bind failed for '{username_clean}': {last_error}"

        # ── Search + Bind Mode ────────────────────────────────────────────────
        elif bind_method == "search_bind":
            service_dn = config.get("service_bind_dn", "")
            service_pwd = config.get("service_bind_password", "")
            search_base = config.get("search_base", "")
            search_filter_tmpl = config.get("search_filter", "(uid={username})")
            user_filter = search_filter_tmpl.format(username=username_clean)

            # Bind service account or anonymous
            conn = ldap3.Connection(
                server,
                user=service_dn if service_dn else None,
                password=service_pwd if service_dn else None,
                auto_bind=False,
                receive_timeout=timeout,
            )
            if use_start_tls:
                conn.open()
                conn.start_tls()

            if not conn.bind():
                return False, "Failed to bind to LDAP with service account/anonymous credentials."

            # Search for User DN
            conn.search(search_base=search_base, search_filter=user_filter, attributes=["dn"])
            if not conn.entries:
                conn.unbind()
                return False, f"User '{username_clean}' not found in LDAP directory base '{search_base}'."

            user_dn = conn.entries[0].entry_dn
            conn.unbind()

            # Bind as target user to check password
            user_conn = ldap3.Connection(
                server,
                user=user_dn,
                password=password,
                auto_bind=False,
                receive_timeout=timeout,
            )
            if use_start_tls:
                user_conn.open()
                user_conn.start_tls()

            if user_conn.bind():
                user_conn.unbind()
                return True, f"Successfully authenticated '{username_clean}' via LDAP search bind."
            else:
                last_error = user_conn.result.get("description", "Invalid credentials")
                return False, f"LDAP user password check failed for '{username_clean}': {last_error}"

        else:
            return False, f"Unsupported LDAP bind_method '{bind_method}'."

    except LDAPException as e:
        return False, f"LDAP server communication error ({server_uri}): {str(e)}"
    except Exception as e:
        return False, f"Unexpected LDAP error: {str(e)}"


# ─────────────────────────────────────────────────────────────────────────────
#  User Loading & Auth Check
# ─────────────────────────────────────────────────────────────────────────────
def load_users() -> list[dict]:
    """Load local user records from users_config.json. Returns empty list on error."""
    if not USERS_CONFIG_PATH.exists():
        return []
    try:
        with open(USERS_CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("users", [])
    except Exception:
        return []


def verify_credentials_detailed(username: str, password: str) -> tuple[bool, str]:
    """
    Authenticate username + password against LDAP server (if enabled) and local users_config.json.
    Returns (success_bool, message_detail).
    """
    username_clean = username.strip()
    if not username_clean or not password:
        return False, "Username and password cannot be empty."

    # 1. Try LDAP authentication if enabled
    ldap_cfg = load_ldap_config()
    if ldap_cfg.get("ldap_enabled", False):
        ldap_ok, ldap_msg = authenticate_ldap(username_clean, password, ldap_cfg)
        if ldap_ok:
            return True, ldap_msg
        elif not ldap_cfg.get("fallback_to_local", True):
            return False, f"LDAP Auth Failed: {ldap_msg} (Local fallback disabled)"

    # 2. Fallback to local user store (users_config.json)
    users = load_users()
    for user in users:
        if user.get("username", "").lower() == username_clean.lower():
            if _check_password(password, user):
                return True, f"Successfully authenticated '{username_clean}' via local users_config.json."
            else:
                return False, "Invalid local password."

    return False, f"User '{username_clean}' not found in LDAP or local database."


def verify_credentials(username: str, password: str) -> bool:
    """Return True if username + password match via LDAP or local users_config.json."""
    success, _ = verify_credentials_detailed(username, password)
    return success



# ─────────────────────────────────────────────────────────────────────────────
#  User Data Directory
# ─────────────────────────────────────────────────────────────────────────────
def get_user_dir(username: str) -> Path:
    """Return (and create) the per-user data directory."""
    user_dir = USER_DATA_ROOT / username
    user_dir.mkdir(parents=True, exist_ok=True)
    (user_dir / "uploads").mkdir(exist_ok=True)
    return user_dir


def get_history_path(username: str) -> Path:
    return get_user_dir(username) / "history.json"


# ─────────────────────────────────────────────────────────────────────────────
#  History CRUD
# ─────────────────────────────────────────────────────────────────────────────
def load_user_history(username: str) -> list[dict]:
    """Load all job records for a user. Returns [] if none exist."""
    path = get_history_path(username)
    if not path.exists():
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save_history(username: str, records: list[dict]) -> None:
    """Atomically write the history list to disk (write-then-rename)."""
    path = get_history_path(username)
    tmp  = path.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, default=str)
    os.replace(tmp, path)


def create_job_record(username: str, filename: str, job_id: Optional[str] = None) -> dict:
    """
    Create a new pending job record, append to history, and return it.
    """
    job_id = job_id or str(uuid.uuid4())
    record = {
        "job_id":       job_id,
        "filename":     filename,
        "uploaded_at":  datetime.now().isoformat(timespec="seconds"),
        "status":       "pending",      # pending | running | completed | failed
        "completed_at": None,
        "error_message": None,
        "results":      None,           # full verification_results dict when done
    }
    records = load_user_history(username)
    records.insert(0, record)           # newest first
    _save_history(username, records)
    return record


def update_job_status(
    username:     str,
    job_id:       str,
    status:       str,
    results:      Optional[dict] = None,
    error_message: Optional[str] = None,
) -> None:
    """Update an existing job record in the user's history."""
    records = load_user_history(username)
    for rec in records:
        if rec["job_id"] == job_id:
            rec["status"] = status
            if results is not None:
                rec["results"] = results
            if error_message is not None:
                rec["error_message"] = error_message
            if status in ("completed", "failed"):
                rec["completed_at"] = datetime.now().isoformat(timespec="seconds")
            break
    _save_history(username, records)


def delete_history_entry(username: str, job_id: str) -> None:
    """Remove a single job record from the user's history."""
    records = load_user_history(username)
    records = [r for r in records if r["job_id"] != job_id]
    _save_history(username, records)


def clear_all_history(username: str) -> None:
    """Delete all job records for the user."""
    _save_history(username, [])


def get_last_completed_job(username: str) -> Optional[dict]:
    """Return the most recent completed job, or None."""
    for rec in load_user_history(username):
        if rec.get("status") == "completed" and rec.get("results"):
            return rec
    return None


# ─────────────────────────────────────────────────────────────────────────────
#  Upload Path Helper
# ─────────────────────────────────────────────────────────────────────────────
def get_upload_path(username: str, job_id: str, filename: str) -> Path:
    """Return the full path where the uploaded file should be stored."""
    user_dir = get_user_dir(username)
    return user_dir / "uploads" / f"{job_id}_{filename}"


# ─────────────────────────────────────────────────────────────────────────────
#  Utility: generate hashes for real users (run standalone to hash passwords)
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        for pwd in sys.argv[1:]:
            print(f"{pwd!r}  →  {hash_password(pwd)}")
    else:
        print("Usage: python auth.py <password1> <password2> ...")
        print("This will print SHA-256 hashes you can paste into users_config.json as 'password_hash' values.")
