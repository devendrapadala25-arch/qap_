"""
test_ldap_cli.py
================
CLI Utility for testing LDAP Server Authentication and Diagnostics in QAP Verification App.

Usage:
    python test_ldap_cli.py
    python test_ldap_cli.py --user johndoe --password secret
"""

import sys
import json
import argparse
from pathlib import Path

# Add current directory to path to ensure auth module can be imported
sys.path.insert(0, str(Path(__file__).parent))

# Safe stdout reconfigure for Windows Unicode encoding
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

from auth import load_ldap_config, verify_credentials_detailed, authenticate_ldap


def main():
    parser = argparse.ArgumentParser(description="Test LDAP authentication settings for QAP Verification App")
    parser.add_argument("-u", "--user", type=str, help="Username to test")
    parser.add_argument("-p", "--password", type=str, help="Password to test")
    parser.add_argument("--ldap-only", action="store_true", help="Bypass local fallback and test LDAP server exclusively")
    args = parser.parse_args()

    print("=" * 65)
    print(" [QAP Security] LDAP Authentication Diagnostic Tool")
    print("=" * 65)

    config = load_ldap_config()
    print("\n[+] Current LDAP Configuration (ldap_config.json):")
    print(f"   • Enabled:            {config.get('ldap_enabled', False)}")
    print(f"   • Server URI:         {config.get('server_uri', 'N/A')}")
    print(f"   • SSL / StartTLS:     SSL={config.get('use_ssl', False)}, StartTLS={config.get('use_start_tls', False)}")
    print(f"   • Bind Method:        {config.get('bind_method', 'direct_bind')}")
    print(f"   • User DN Template:   {config.get('user_dn_template', 'N/A')}")
    print(f"   • Search Base:        {config.get('search_base', 'N/A')}")
    print(f"   • Search Filter:      {config.get('search_filter', 'N/A')}")
    print(f"   • Local Fallback:     {config.get('fallback_to_local', True)}")
    print("-" * 65)

    username = args.user
    password = args.password

    if not username:
        username = input("\n[*] Enter test username: ").strip()
    if not password:
        import getpass
        password = getpass.getpass("[*] Enter test password: ")

    if not username or not password:
        print("[!] Username and password are required to test authentication.")
        sys.exit(1)

    print(f"\n[*] Testing authentication for user '{username}'...")

    if args.ldap_only:
        success, msg = authenticate_ldap(username, password, config)
    else:
        success, msg = verify_credentials_detailed(username, password)

    if success:
        print("\n[SUCCESS] AUTHENTICATION PASSED!")
        print(f"   Details: {msg}")
    else:
        print("\n[FAILED] AUTHENTICATION FAILED!")
        print(f"   Details: {msg}")
        print("\n[?] Troubleshooting Tips:")
        print("   1. Verify LDAP server URI in ldap_config.json (e.g. ldap://172.27.30.222:389).")
        print("   2. Check user_dn_template (for Active Directory use '{username}@domain.com', for OpenLDAP use 'uid={username},ou=users,dc=example,dc=com').")
        print("   3. If using search_bind mode, ensure service_bind_dn & service_bind_password are valid.")
        print("   4. Ensure firewall allows connection on port 389 (LDAP) or 636 (LDAPS).")

    print("\n" + "=" * 65)


if __name__ == "__main__":
    main()
