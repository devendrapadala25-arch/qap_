"""
section_extractor.py  (v2 – ground-up rewrite)
================================================
Converts a MinerU-produced Markdown file into a rich structural representation
suitable for QAP checklist verification.

Pipeline
--------
Step 1  Extract every line that starts with '#' (after stripping leading WS).
        → hash_headings : list[HeadingEntry]

Step 2  Locate the Table-of-Contents / Index / Content page.
        Supports:
          • HTML <table> TOC  (EI-Wave style)
          • Plain-text TOC    (numeric + non-numeric entries)
        Handles cross-page TOC (content split across two pages).
        → toc_entries  : list[dict]   {text, numeric, page}
        → toc_start, toc_end : int    (line numbers, inclusive)

Step 3  Search the body (OUTSIDE the TOC block) for the real line where
        each TOC heading appears.
        Strategy – word-boundary matching:
          a) Exact strip match
          b) First-3 + Last-3 token overlap on a single body line
          c) RapidFuzz token_sort_ratio ≥ 72
          d) Search inside <td> cell text of tables
        → toc_body_headings : list[HeadingEntry]   (with correct body line nums)
        Remember the FIRST numeric TOC entry → first_numeric_anchor

Step 4  Merge hash_headings + toc_body_headings; sort by line_num.
        Also sweep for plain-text numeric headings (no '#') that were missed.
        Deduplicate within ±2 lines (priority: hash > toc_body > plain).

Step 5  Build the Section Tree starting from first_numeric_anchor.
        • Preamble  = headings before anchor (flat list of SectionNodes)
        • Numbered tree  = stack-based parent/child by numeric depth
          – Non-numeric headings between numeric ones → leaf at current depth
          – own_content = lines[this_heading .. next_heading)
          – content     = own_content + all descendant content

Step 6  Build Table Tree.
        Every <table>…</table> block (outside TOC) becomes a TableNode:
          title      = last short non-blank non-heading line before <table>
          html       = raw HTML
          cell_text  = all cell text joined
          start/end  lines

Step 7  Build Figure Tree.
        Scan for ![caption](path) and "Figure N" / "Fig. N" captions.
        → list[FigureNode]
"""

from __future__ import annotations

import re
import hashlib
import logging
from dataclasses import dataclass, field
from typing import Optional

from bs4 import BeautifulSoup
from rapidfuzz import fuzz

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
#  Data-classes
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class HeadingEntry:
    line_num:   int
    text:       str          # cleaned (no '#', numeric prefix kept)
    raw_text:   str
    level:      int          # numeric depth (1 = top); 0 = special / unknown
    numeric:    Optional[str]  # "1" | "1.2" | "1.2.3" | None
    source:     str          # "hash" | "toc_body" | "plain_numeric" | "plain_special"
    is_special: bool = False


@dataclass
class SectionNode:
    heading:     HeadingEntry
    own_content: str
    content:     str = ""
    children:    list = field(default_factory=list)  # list[SectionNode]
    start_line:  int = 0
    end_line:    int = 0

    @property
    def label(self) -> str:
        return self.heading.text

    @property
    def numeric_prefix(self) -> Optional[str]:
        return self.heading.numeric

    def flat_children(self) -> list[SectionNode]:
        result: list[SectionNode] = []
        for c in self.children:
            result.append(c)
            result.extend(c.flat_children())
        return result


@dataclass
class TableNode:
    title:      str          # caption / name of the table
    html:       str          # raw HTML of the <table>
    cell_text:  str          # all cell text joined by '\n'
    start_line: int
    end_line:   int
    section_heading: str = ""


@dataclass
class FigureNode:
    caption:    str
    ref:        str          # image path or figure label
    context:    str          # up to 3 surrounding lines
    line_num:   int


# ─────────────────────────────────────────────────────────────────────────────
#  Constants
# ─────────────────────────────────────────────────────────────────────────────

# Numeric heading prefix: "1", "1.", "1.2", "1.2.", "1.2.3", …
NUMERIC_RE = re.compile(r"^(\d+(?:\.\d+)*\.?)\s+(.+)")

# TOC trigger lines (bare line equals one of these)
TOC_TRIGGERS = {"table of contents", "contents", "toc", "index", "content"}

# Plain-text TOC entry with page number at end
_TOC_NUM_RE    = re.compile(r"^(\d[\d.]*\.?\s+.+?)\s{1,}(\d+)\s*$")
_TOC_NONNUM_RE = re.compile(r"^([A-Za-z][A-Za-z\s/,&.()\-]{2,}?)\s{1,}(\d+)\s*$")

# Markdown image
_IMG_RE = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
# Figure captions
_FIG_CAP_RE = re.compile(r"(?i)^(fig(?:ure)?\.?\s*\d[\d.]*[:\-\s].{3,80})$")

KNOWN_SPECIAL = [
    "record of amendments", "amendments record sheet", "amendment sheet",
    "amendment record", "amendment history", "revision history",
    "table of contents", "contents", "index",
    "list of tables", "list of figures", "list of annexures",
    "list of abbreviations", "abbreviations", "abbreviation",
    "glossary", "proprietary information", "distribution list",
]


# ─────────────────────────────────────────────────────────────────────────────
#  Utilities
# ─────────────────────────────────────────────────────────────────────────────

def _norm(text: str) -> str:
    """Lowercase, strip numeric prefix, collapse whitespace."""
    t = text.lower().strip()
    t = re.sub(r"^\d[\d.]*\.?\s+", "", t)
    return re.sub(r"\s+", " ", t).strip()


def _parse_numeric(raw: str) -> tuple[Optional[str], int]:
    """Return (numeric_prefix, depth).  E.g. '1.2.3.' → ('1.2.3', 3)."""
    m = NUMERIC_RE.match(raw.strip())
    if not m:
        return None, 0
    num = m.group(1).rstrip(".")
    return num, len(num.split("."))


def _is_special(text: str) -> bool:
    norm = _norm(text)
    for kw in KNOWN_SPECIAL:
        if kw == norm or kw in norm or norm in kw:
            return True
        if len(kw) > 5 and fuzz.token_sort_ratio(kw, norm) >= 80:
            return True
    return False


def _tokens(text: str) -> list[str]:
    """Lower-case alphabetic tokens."""
    return [w.lower() for w in re.findall(r"[a-zA-Z]+", text)]


# ─────────────────────────────────────────────────────────────────────────────
#  Table-block helpers
# ─────────────────────────────────────────────────────────────────────────────

def _find_table_blocks(lines: list[str]) -> list[tuple[int, int, str]]:
    """Return [(start, end, html)] for every <table>…</table> block."""
    blocks: list[tuple[int, int, str]] = []
    buf: list[str] = []
    start = -1
    depth = 0

    for i, line in enumerate(lines):
        lo = line.lower()
        opens  = lo.count("<table")
        closes = lo.count("</table")

        if opens and depth == 0:
            start = i
            buf = []

        if start != -1:
            buf.append(line)

        depth += opens - closes

        if depth <= 0 and start != -1:
            blocks.append((start, i, "\n".join(buf)))
            start = -1
            buf = []
            depth = 0

    return blocks


def _table_regions(lines: list[str]) -> list[tuple[int, int]]:
    return [(s, e) for s, e, _ in _find_table_blocks(lines)]


def _in_table(ln: int, regions: list[tuple[int, int]]) -> bool:
    for s, e in regions:
        if s <= ln <= e:
            return True
    return False


def _in_range(ln: int, start: int, end: int) -> bool:
    return start <= ln <= end


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 0 – Strip repeated page-header tables
# ─────────────────────────────────────────────────────────────────────────────

def _table_fingerprint(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    rows  = soup.find_all("tr")
    cells = [td.get_text(strip=True)[:40] for td in soup.find_all("td")]
    key = f"r={len(rows)}|{'|'.join(cells[:6])}"
    return hashlib.md5(key.encode()).hexdigest()


def strip_page_headers(md: str, min_repeat: int = 3) -> tuple[str, set[int]]:
    lines = md.split("\n")
    blocks = _find_table_blocks(lines)

    fp_count: dict[str, list[tuple[int, int]]] = {}
    for s, e, html in blocks:
        fp = _table_fingerprint(html)
        fp_count.setdefault(fp, []).append((s, e))

    bad: set[int] = set()
    for fp, ranges in fp_count.items():
        if len(ranges) >= min_repeat:
            for s, e in ranges:
                bad.update(range(s, e + 1))

    cleaned = "\n".join(l for i, l in enumerate(lines) if i not in bad)
    return cleaned, bad


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 1 – Extract '#' headings
# ─────────────────────────────────────────────────────────────────────────────

def extract_hash_headings(lines: list[str]) -> list[HeadingEntry]:
    """
    Every line that starts with '#' (after stripping leading whitespace).
    Handles leading whitespace correctly.
    """
    result: list[HeadingEntry] = []
    for i, line in enumerate(lines):
        stripped = line.lstrip()          # strip leading whitespace first
        if not stripped.startswith("#"):
            continue
        hash_count = len(stripped) - len(stripped.lstrip("#"))
        text = stripped.lstrip("#").strip()
        if not text:
            continue

        numeric, depth = _parse_numeric(text)
        is_spec = (numeric is None) and _is_special(text)
        level   = depth if numeric else (hash_count if not is_spec else 0)

        result.append(HeadingEntry(
            line_num   = i,
            text       = text,
            raw_text   = line,
            level      = level,
            numeric    = numeric,
            source     = "hash",
            is_special = is_spec,
        ))
    return result


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 2 – Detect & parse the TOC block
# ─────────────────────────────────────────────────────────────────────────────

def _parse_html_toc(html: str) -> list[dict]:
    entries: list[dict] = []
    soup = BeautifulSoup(html, "html.parser")
    for row in soup.find_all("tr"):
        cells = [td.get_text(separator=" ", strip=True) for td in row.find_all(["td", "th"])]
        if len(cells) < 2:
            continue
        first = cells[0].strip()
        # Skip header rows
        if first.lower() in {"contents", "table of contents", "toc", "index",
                              "sl.no", "s.no", "sno", "sr.no"}:
            continue
        if len(first) < 2:
            continue
        # Find page number: last cell that is all-digit
        page: Optional[int] = None
        for cell in reversed(cells):
            c = cell.strip()
            if c.isdigit():
                page = int(c)
                break
        if page is None:
            continue
        numeric, _ = _parse_numeric(first)
        if len(first) > 3:
            entries.append({"text": first, "numeric": numeric, "page": page})
    return entries


def _parse_plain_toc(lines: list[str], start: int) -> tuple[list[dict], int]:
    """
    Read plain-text TOC entries from line 'start'.
    Handles cross-page: stops only when ≥5 consecutive non-entry non-blank lines
    appear (or a '#' heading / new <table> start).
    Returns (entries, exclusive_end_line).
    """
    entries: list[dict] = []
    i = start
    bad_streak = 0

    while i < len(lines):
        raw = lines[i]
        line = raw.strip()

        # Hard stops
        if line.startswith("#"):
            break

        # Skip HTML tags completely and do not increment bad_streak
        if line.startswith("<") or line.startswith("</") or line.endswith(">"):
            i += 1
            continue

        if not line:
            i += 1
            continue

        # Numbered entry: "1.2.3. Heading text   45"
        m = _TOC_NUM_RE.match(line)
        if m:
            hdg = m.group(1).strip()
            page = int(m.group(2))
            num, _ = _parse_numeric(hdg)
            entries.append({"text": hdg, "numeric": num, "page": page})
            bad_streak = 0
            i += 1
            continue

        # Non-numbered entry: "List of Figures   13"
        m2 = _TOC_NONNUM_RE.match(line)
        if m2:
            entry_text = m2.group(1).strip()
            # Must be plausible TOC entry (not a body sentence)
            alpha_ratio = sum(c.isalpha() for c in entry_text) / max(len(entry_text), 1)
            if alpha_ratio > 0.45 and 3 < len(entry_text) < 100:
                page = int(m2.group(2))
                entries.append({"text": entry_text, "numeric": None, "page": page})
                bad_streak = 0
                i += 1
                continue

        bad_streak += 1
        if bad_streak >= 6:
            break
        i += 1

    return entries, i


def detect_toc(lines: list[str]) -> tuple[list[dict], int, int]:
    """
    Returns (toc_entries, toc_start, toc_end).
    toc_start = toc_end = -1 if no TOC found.
    """
    toc_entries: list[dict] = []
    toc_start = -1
    toc_end   = -1

    table_blocks = _find_table_blocks(lines)

    # ── Try HTML-table TOC (scan ALL table blocks, not just first 300 lines) ──
    html_ranges: list[tuple[int, int]] = []
    for s, e, html in table_blocks:
        soup = BeautifulSoup(html, "html.parser")
        first_cells = [
            td.get_text(strip=True).lower()
            for td in soup.find_all(["td", "th"])[:30]
        ]
        joined = " ".join(first_cells)
        if any(kw in joined for kw in ("contents", "table of contents", "index")):
            ents = _parse_html_toc(html)
            if len(ents) >= 3:
                toc_entries.extend(ents)
                html_ranges.append((s, e))

    if html_ranges:
        toc_start = html_ranges[0][0]
        toc_end   = html_ranges[-1][1]
        logger.debug(f"HTML TOC: lines {toc_start}–{toc_end}, {len(toc_entries)} entries")
        return toc_entries, toc_start, toc_end

    # ── Try plain-text TOC (scan first 500 lines) ────────────────────────────
    for i, line in enumerate(lines[:500]):
        # Strip leading # and whitespace
        stripped = line.strip().lstrip("#").strip().lower().rstrip(".")
        if stripped in TOC_TRIGGERS:
            # Check if the very next non-blank line is a <table> (HTML TOC)
            j = i + 1
            while j < len(lines) and not lines[j].strip():
                j += 1
            if j < len(lines) and lines[j].strip().lower().startswith("<table"):
                # Parse as HTML TOC
                for s, e, html in table_blocks:
                    if s <= j <= e:
                        ents = _parse_html_toc(html)
                        if len(ents) >= 3:
                            toc_entries = ents
                            toc_start   = i
                            toc_end     = e
                            logger.debug(f"Plain-header + HTML TOC: {toc_start}–{toc_end}")
                            return toc_entries, toc_start, toc_end
                        break

            # Plain text TOC
            ents, end_line = _parse_plain_toc(lines, i + 1)
            if len(ents) >= 3:
                toc_entries = ents
                toc_start   = i
                toc_end     = end_line
                logger.debug(f"Plain-text TOC: lines {toc_start}–{toc_end}, "
                              f"{len(ents)} entries")
                break

    return toc_entries, toc_start, toc_end


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 3 – Locate each TOC heading in the document BODY (skip TOC block)
# ─────────────────────────────────────────────────────────────────────────────

def _line_word_match(entry_tokens: list[str], line: str) -> bool:
    """
    Word-boundary match: first-3 AND last-3 tokens of the TOC entry must all
    appear in the body line (order-insensitive).
    """
    line_toks = set(_tokens(line))
    first3 = set(entry_tokens[:3])
    last3  = set(entry_tokens[-3:]) if len(entry_tokens) > 3 else set()
    # Both subsets must be covered
    if first3 and not first3.issubset(line_toks):
        return False
    if last3 and not last3.issubset(line_toks):
        return False
    return bool(first3)  # need at least first-3


def _cell_texts_from_table(html: str) -> list[str]:
    soup = BeautifulSoup(html, "html.parser")
    return [td.get_text(separator=" ", strip=True) for td in soup.find_all("td")]


def find_toc_headings_in_body(
    toc_entries: list[dict],
    lines: list[str],
    toc_start: int,
    toc_end: int,
    table_blocks: list[tuple[int, int, str]],
    fuzzy_threshold: int = 72,
) -> tuple[list[HeadingEntry], Optional[HeadingEntry]]:
    """
    For each TOC entry, find the actual line in the BODY where that heading
    appears.  The search window is strictly AFTER toc_end.

    Returns (body_headings, first_numeric_anchor).
    first_numeric_anchor = the HeadingEntry for the first numeric TOC entry
    found in the body.
    """
    body_start = max(toc_end + 1, 0)
    found:  list[HeadingEntry] = []
    first_numeric_anchor: Optional[HeadingEntry] = None

    for entry in toc_entries:
        entry_text  = entry["text"].strip()
        entry_norm  = _norm(entry_text)
        entry_toks  = _tokens(entry_text)
        entry_num   = entry["numeric"]

        best_score  = 0
        best_line   = -1

        # For special/front-matter entries, search the whole document.
        # For numeric entries, search strictly after the TOC block.
        is_entry_special = (entry_num is None) or _is_special(entry_text)
        start_scan = 0 if is_entry_special else body_start

        # ── Scan every body line ──────────────────────────────────────────
        for idx in range(start_scan, len(lines)):
            if toc_start <= idx <= toc_end:
                continue
            raw = lines[idx]

            # a) Exact strip match (after removing leading '#' and whitespace)
            stripped = raw.lstrip().lstrip("#").strip()
            if stripped and _norm(stripped) == entry_norm:
                best_score = 100
                best_line  = idx
                break

            # b) Word-boundary: first-3 + last-3 tokens
            if _line_word_match(entry_toks, raw):
                score = fuzz.token_sort_ratio(entry_norm, _norm(raw))
                if score > best_score:
                    best_score = score
                    best_line  = idx

            # c) Fuzzy on the raw stripped line
            if stripped:
                score = fuzz.token_sort_ratio(entry_norm, _norm(stripped))
                if score > best_score:
                    best_score = score
                    best_line  = idx

        # ── Also check <td> cells in tables ─────────────────────────────
        for s, e, html in table_blocks:
            if e < start_scan:
                continue
            # Skip the TOC table itself
            if toc_start <= s <= toc_end:
                continue
            for cell in _cell_texts_from_table(html):
                if not cell:
                    continue
                score = fuzz.token_sort_ratio(entry_norm, _norm(cell))
                if score > best_score:
                    best_score = score
                    best_line  = s   # use table start line

        if best_line >= start_scan and best_score >= fuzzy_threshold:
            depth = len(entry_num.split(".")) if entry_num else 0
            he = HeadingEntry(
                line_num   = best_line,
                text       = lines[best_line].lstrip().lstrip("#").strip() or entry_text,
                raw_text   = lines[best_line],
                level      = depth,
                numeric    = entry_num,
                source     = "toc_body",
                is_special = (entry_num is None),
            )
            found.append(he)

            # Remember first numeric heading from TOC found in body
            if entry_num and first_numeric_anchor is None:
                first_numeric_anchor = he
        else:
            logger.debug(
                f"TOC entry NOT found in body: '{entry_text}'  "
                f"best_score={best_score}  best_line={best_line}"
            )

    return found, first_numeric_anchor


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 4 – Merge hash + toc_body + plain-numeric, deduplicate, sort
# ─────────────────────────────────────────────────────────────────────────────

_SRC_PRIORITY = {
    "hash":          5,
    "plain_numeric": 4,
    "toc_body":      3,
    "table_header":  2,
    "plain_special": 1,
}


def _detect_plain_numeric(
    lines: list[str],
    table_regions: list[tuple[int, int]],
    existing: set[int],
    toc_start: int,
    toc_end: int,
) -> list[HeadingEntry]:
    """Plain-text numeric headings with no '#'."""
    result: list[HeadingEntry] = []
    for i, line in enumerate(lines):
        if i in existing:
            continue
        if _in_table(i, table_regions):
            continue
        if toc_start <= i <= toc_end:
            continue
        stripped = line.strip()
        if not stripped or len(stripped) > 150:
            continue
        m = NUMERIC_RE.match(stripped)
        if not m:
            continue
        remainder = m.group(2).strip()
        if len(remainder) < 2:
            continue
        numeric, depth = _parse_numeric(stripped)
        # Context: preceded by a blank line, table end, or image
        prev = ""
        for j in range(i - 1, max(i - 5, -1), -1):
            if lines[j].strip():
                prev = lines[j].strip()
                break
        heading_signal = (
            remainder == remainder.upper()
            or not prev
            or prev.endswith(">")
            or prev.endswith(".jpg)")
            or prev.endswith(".png)")
        )
        trailing_ws = line != line.rstrip()
        if heading_signal or trailing_ws:
            result.append(HeadingEntry(
                line_num   = i,
                text       = stripped,
                raw_text   = line,
                level      = depth,
                numeric    = numeric,
                source     = "plain_numeric",
                is_special = False,
            ))
    return result


def _detect_plain_special(
    lines: list[str],
    existing: set[int],
    toc_start: int,
    toc_end: int,
) -> list[HeadingEntry]:
    """
    Extract plain-text special headings (e.g., 'AMENDMENTS RECORD SHEET')
    that have no '#' and no numeric prefix, but match one of the KNOWN_SPECIAL keywords.
    Handles lines containing HTML tags by stripping them first.
    """
    result: list[HeadingEntry] = []
    for i, line in enumerate(lines):
        if i in existing:
            continue
        if toc_start <= i <= toc_end:
            continue
        
        # Strip HTML tags to check the actual text content of the line
        clean_text = re.sub(r"<[^>]+>", "", line).strip()
        if not clean_text or len(clean_text) > 120:
            continue
            
        # Check if this text is in KNOWN_SPECIAL
        if _is_special(clean_text):
            # Exclude lines that end with a sentence period unless it's just part of abbreviation (e.g. 'Fig.')
            if clean_text.endswith(".") and not clean_text.replace(".","").isdigit() and len(clean_text.split()) > 3:
                continue
            
            result.append(HeadingEntry(
                line_num   = i,
                text       = clean_text,
                raw_text   = line,
                level      = 1,
                numeric    = None,
                source     = "plain_special",
                is_special = True,
            ))
    return result


def build_master_headings(
    hash_headings:    list[HeadingEntry],
    toc_body:         list[HeadingEntry],
    plain_numeric:    list[HeadingEntry],
) -> list[HeadingEntry]:
    all_h: list[HeadingEntry] = hash_headings + toc_body + plain_numeric

    # Deduplicate by line number (keep highest priority source)
    by_line: dict[int, HeadingEntry] = {}
    for h in all_h:
        prev = by_line.get(h.line_num)
        if prev is None or _SRC_PRIORITY.get(h.source, 0) > _SRC_PRIORITY.get(prev.source, 0):
            by_line[h.line_num] = h

    sorted_h = sorted(by_line.values(), key=lambda h: h.line_num)

    # Proximity dedup: within ±2 lines keep higher priority
    deduped: list[HeadingEntry] = []
    for h in sorted_h:
        if deduped and abs(h.line_num - deduped[-1].line_num) <= 2:
            if _SRC_PRIORITY.get(h.source, 0) > _SRC_PRIORITY.get(deduped[-1].source, 0):
                deduped[-1] = h
        else:
            deduped.append(h)

    return deduped


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 5 – Build Section Tree
# ─────────────────────────────────────────────────────────────────────────────

def _content(lines: list[str], start: int, end: int) -> str:
    return "\n".join(lines[start:end]).strip()


def _build_preamble(
    headings: list[HeadingEntry], anchor_line: int, lines: list[str]
) -> list[SectionNode]:
    nodes: list[SectionNode] = []
    n = len(headings)
    for i, h in enumerate(headings):
        nxt = headings[i + 1].line_num if i + 1 < n else anchor_line
        own = _content(lines, h.line_num, nxt)
        nodes.append(SectionNode(
            heading     = h,
            own_content = own,
            content     = own,
            children    = [],
            start_line  = h.line_num,
            end_line    = nxt - 1,
        ))
    return nodes


def _build_numbered_tree(
    headings: list[HeadingEntry], lines: list[str], total: int
) -> list[SectionNode]:
    if not headings:
        return []

    # First pass: flat nodes with own_content
    flat: list[SectionNode] = []
    n = len(headings)
    for i, h in enumerate(headings):
        nxt = headings[i + 1].line_num if i + 1 < n else total
        own = _content(lines, h.line_num, nxt)
        flat.append(SectionNode(
            heading     = h,
            own_content = own,
            content     = "",
            children    = [],
            start_line  = h.line_num,
            end_line    = nxt - 1,
        ))

    # Second pass: parent/child assignment
    roots: list[SectionNode] = []
    stack: list[tuple[int, SectionNode]] = []  # (depth, node)

    for node in flat:
        h = node.heading
        if h.numeric:
            depth = len(h.numeric.split("."))
        else:
            # Non-numeric: leaf at the depth of the nearest predecessor + 1
            depth = (stack[-1][0] + 1) if stack else 1

        while stack and stack[-1][0] >= depth:
            stack.pop()

        if stack:
            stack[-1][1].children.append(node)
        else:
            roots.append(node)

        stack.append((depth, node))

    # Third pass: fill content (own + all descendants)
    def _fill(node: SectionNode) -> None:
        for c in node.children:
            _fill(c)
        if node.children:
            last_end = max(d.end_line for d in node.flat_children())
            node.content = _content(lines, node.start_line, last_end + 1)
        else:
            node.content = node.own_content

    for r in roots:
        _fill(r)

    return roots


def build_section_tree(
    all_headings: list[HeadingEntry],
    lines: list[str],
    anchor_idx: int,
) -> tuple[list[SectionNode], list[SectionNode]]:
    total = len(lines)
    preamble_hdgs = all_headings[:anchor_idx]
    numbered_hdgs = all_headings[anchor_idx:]
    anchor_line   = numbered_hdgs[0].line_num if numbered_hdgs else total

    preamble = _build_preamble(preamble_hdgs, anchor_line, lines)
    tree     = _build_numbered_tree(numbered_hdgs, lines, total)
    return preamble, tree


def flatten_tree(nodes: list[SectionNode]) -> list[SectionNode]:
    out: list[SectionNode] = []
    for node in nodes:
        out.append(node)
        out.extend(flatten_tree(node.children))
    return out


def _is_metadata_cell(text: str) -> bool:
    """Return True if the cell contains metadata labels or page header noise."""
    t = text.lower().strip()
    if not t or len(t) < 2:
        return True
        
    metadata_keywords = {
        "doc name", "doc. name", "document name",
        "doc no", "doc. no", "document no",
        "ver.", "ver", "version", "rev.", "rev", "revision",
        "date", "dated", "issue", "is. no", "issue no",
        "classified", "restricted", "confidential",
        "under ip license", "nda only", "lekha", "dlc-mu", "saaw",
        "page no", "page number"
    }
    
    for kw in metadata_keywords:
        if t.startswith(kw) or t == kw or (len(t) < 40 and kw in t):
            return True
            
    return False


def build_table_tree(
    lines: list[str],
    table_blocks: list[tuple[int, int, str]],
    toc_start: int,
    toc_end: int,
    all_headings: list[HeadingEntry] = None,
) -> list[TableNode]:
    nodes: list[TableNode] = []

    for s, e, html in table_blocks:
        # Skip the TOC table itself
        if toc_start <= s <= toc_end or toc_start <= e <= toc_end:
            continue

        # Find the nearest preceding heading
        section_heading = "Preamble"
        if all_headings:
            for h in reversed(all_headings):
                if h.line_num < s:
                    section_heading = h.text
                    break

        # Find title: last short non-blank line before <table>
        title = ""
        for k in range(s - 1, max(s - 8, -1), -1):
            candidate = lines[k].lstrip().lstrip("#").strip()
            if candidate and len(candidate) <= 150 and not candidate.startswith("<"):
                title = candidate
                break

        # Extract cells and look below metadata headers to resolve correct title/section
        soup = BeautifulSoup(html, "html.parser")
        cells = soup.find_all(["td", "th"])
        cell_texts = [td.get_text(separator=" ", strip=True) for td in cells]
        
        inner_title = ""
        for c_text in cell_texts:
            if c_text and not _is_metadata_cell(c_text):
                inner_title = c_text
                break
                
        # If the first content cell matches a known special heading, override title and section
        if inner_title:
            lower_inner = inner_title.lower()
            if _is_special(inner_title) or any(kw in lower_inner for kw in ("table of contents", "list of", "abbreviation", "proprietary", "amendment", "amendments", "revision history")):
                title = inner_title
                section_heading = inner_title

        # Fallback if no title was found from the preceding line
        if not title:
            if inner_title:
                title = inner_title
            elif cell_texts:
                title = cell_texts[0]
            else:
                title = f"Table at line {s}"
        title = title[:120]

        # Extract all cell text
        cell_text = "\n".join(filter(None, cell_texts))

        nodes.append(TableNode(
            title           = title or f"Table at line {s}",
            html            = html,
            cell_text       = cell_text,
            start_line      = s,
            end_line        = e,
            section_heading = section_heading,
        ))

    return nodes


# ─────────────────────────────────────────────────────────────────────────────
#  STEP 7 – Build Figure Tree
# ─────────────────────────────────────────────────────────────────────────────

def build_figure_tree(lines: list[str]) -> list[FigureNode]:
    nodes: list[FigureNode] = []
    seen_lines: set[int] = set()

    for i, line in enumerate(lines):
        if i in seen_lines:
            continue

        # Markdown image: ![caption](path)
        for m in _IMG_RE.finditer(line):
            caption = m.group(1).strip()
            ref     = m.group(2).strip()
            # Context: surrounding 2 lines
            ctx_lines = lines[max(0, i - 1): min(len(lines), i + 3)]
            ctx = "\n".join(ctx_lines)

            # If caption is empty, look at the preceding / following line
            if not caption:
                if i > 0:
                    caption = lines[i - 1].strip()[:80]
                if not caption and i + 1 < len(lines):
                    caption = lines[i + 1].strip()[:80]
            if not caption:
                caption = f"Figure at line {i}"

            nodes.append(FigureNode(
                caption  = caption,
                ref      = ref,
                context  = ctx,
                line_num = i,
            ))
            seen_lines.add(i)

        # Figure caption line: "Figure 3.2: Title text"
        cap_m = _FIG_CAP_RE.match(line.strip())
        if cap_m and i not in seen_lines:
            caption = cap_m.group(1).strip()
            # Look forward for an image on the next 3 lines
            ref = ""
            for k in range(i + 1, min(len(lines), i + 4)):
                img_m = _IMG_RE.search(lines[k])
                if img_m:
                    ref = img_m.group(2).strip()
                    seen_lines.add(k)
                    break
            ctx = "\n".join(lines[max(0, i - 1): min(len(lines), i + 4)])
            nodes.append(FigureNode(
                caption  = caption,
                ref      = ref,
                context  = ctx,
                line_num = i,
            ))
            seen_lines.add(i)

    return nodes


# ─────────────────────────────────────────────────────────────────────────────
#  Public API
# ─────────────────────────────────────────────────────────────────────────────

def extract_sections(markdown_text: str) -> dict:
    """
    Full 7-step pipeline: raw MinerU markdown → structured section representation.

    Returns
    -------
    {
        "preamble"     : list[SectionNode]     – front-matter flat nodes
        "tree"         : list[SectionNode]     – numbered root nodes (with children)
        "flat"         : list[SectionNode]     – depth-first all nodes
        "table_nodes"  : list[TableNode]
        "figure_nodes" : list[FigureNode]
        "toc_entries"  : list[dict]            – raw TOC entries {text,numeric,page}
        "anchor"       : HeadingEntry | None   – first numeric level-1 heading
        "lines"        : list[str]             – cleaned markdown lines
    }
    """
    # Step 0 – strip repeated page-header tables
    cleaned_md, _ = strip_page_headers(markdown_text)
    
    # Split HTML table rows and blocks across lines so they receive unique line numbers
    cleaned_md = re.sub(r"(?i)<table>\s*<tr>", "<table>\n<tr>", cleaned_md)
    cleaned_md = re.sub(r"(?i)</tr>\s*<tr>", "</tr>\n<tr>", cleaned_md)
    cleaned_md = re.sub(r"(?i)</tr>\s*</table>", "</tr>\n</table>", cleaned_md)
    
    lines = cleaned_md.split("\n")

    # Step 1 – '#' headings
    hash_headings = extract_hash_headings(lines)
    logger.info(f"Step 1: {len(hash_headings)} '#'-headings extracted")

    # Step 2 – TOC detection
    toc_entries, toc_start, toc_end = detect_toc(lines)
    logger.info(
        f"Step 2: TOC {'found' if toc_start >= 0 else 'NOT found'} "
        f"lines {toc_start}–{toc_end}, {len(toc_entries)} entries"
    )

    # Table blocks (needed for Steps 3, 6)
    table_blocks = _find_table_blocks(lines)
    table_regions = [(s, e) for s, e, _ in table_blocks]

    # Step 3 – Locate TOC entries in body
    toc_body, first_numeric_anchor = find_toc_headings_in_body(
        toc_entries, lines, toc_start, toc_end, table_blocks
    )
    logger.info(
        f"Step 3: {len(toc_body)} TOC entries resolved in body; "
        f"first_numeric_anchor={first_numeric_anchor.text if first_numeric_anchor else 'None'}"
    )

    # Step 4 – Plain-numeric & plain-special sweep + merge
    existing_lines = {h.line_num for h in hash_headings} | {h.line_num for h in toc_body}
    plain_numeric = _detect_plain_numeric(
        lines, table_regions, existing_lines, toc_start, toc_end
    )
    existing_lines.update(h.line_num for h in plain_numeric)
    plain_special = _detect_plain_special(
        lines, existing_lines, toc_start, toc_end
    )
    master = build_master_headings(hash_headings, toc_body, plain_numeric + plain_special)
    logger.info(f"Step 4: {len(master)} master headings after merge")

    # Step 5 – Build section tree
    # Anchor = first top-level numeric heading in the BODY (after the TOC).
    # Three-pass strategy:
    #   Pass A: first level-1 toc_body heading (most reliable – already resolved to body)
    #   Pass B: first level-1 numeric in master list whose line > toc_end
    #   Pass C: first level-1 numeric anywhere in master list
    anchor_idx = 0
    anchor: Optional[HeadingEntry] = None

    # Pass A — from toc_body headings (these are already body line numbers)
    for tbh in toc_body:
        if tbh.numeric and "." not in tbh.numeric:
            # find its index in master
            for i, h in enumerate(master):
                if abs(h.line_num - tbh.line_num) <= 3:
                    anchor_idx = i
                    anchor     = h
                    break
            if anchor is not None:
                break

    # Pass B — first level-1 numeric in master after the TOC
    if anchor is None:
        for i, h in enumerate(master):
            if h.numeric and "." not in h.numeric and h.line_num > max(toc_end, -1):
                anchor_idx = i
                anchor     = h
                break

    # Pass C — absolute first level-1 numeric in master
    if anchor is None:
        for i, h in enumerate(master):
            if h.numeric and "." not in h.numeric:
                anchor_idx = i
                anchor     = h
                break

    preamble_nodes, tree_nodes = build_section_tree(master, lines, anchor_idx)
    all_flat = preamble_nodes + flatten_tree(tree_nodes)
    logger.info(
        f"Step 5: preamble={len(preamble_nodes)}, tree_roots={len(tree_nodes)}, "
        f"flat={len(all_flat)}"
    )

    # Step 6 – Table tree
    table_nodes = build_table_tree(lines, table_blocks, toc_start, toc_end, master)
    logger.info(f"Step 6: {len(table_nodes)} table nodes")

    # Step 7 – Figure tree
    figure_nodes = build_figure_tree(lines)
    logger.info(f"Step 7: {len(figure_nodes)} figure nodes")

    return {
        "preamble"     : preamble_nodes,
        "tree"         : tree_nodes,
        "flat"         : all_flat,
        "table_nodes"  : table_nodes,
        "figure_nodes" : figure_nodes,
        "toc_entries"  : toc_entries,
        "anchor"       : anchor,
        "lines"        : lines,
    }
