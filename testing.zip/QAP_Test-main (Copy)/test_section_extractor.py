"""
test_section_extractor.py
=========================
Standalone test script for section_extractor.py and section_matcher.py.

Usage:
    python test_section_extractor.py  path/to/document.md  [path/to/checklist.json]

If no checklist is provided, a sample 5-item checklist is used.
Prints a structured report of:
  - Detected TOC entries
  - Preamble sections
  - Numbered section tree (truncated preview)
  - Checklist → section mapping results
"""

import sys
import json
import textwrap
from pathlib import Path

from section_extractor import extract_sections
from section_matcher   import match_checklist_to_sections


# ─── Sample checklist (used when none is provided on CLI) ────────────────────
SAMPLE_CHECKLIST = [
    {
        "id": 1,
        "section_name": "Amendments sheet",
        "question": "Is the amendments / revision history sheet present?",
        "prompt": "Check if an amendments or revision history sheet is present in the document.",
    },
    {
        "id": 2,
        "section_name": "Introduction",
        "question": "Is the introduction section present with scope and purpose?",
        "prompt": "Verify that an introduction section exists and contains scope/purpose details.",
    },
    {
        "id": 3,
        "section_name": "List of Tables",
        "question": "Is a list of tables provided?",
        "prompt": "Check whether a 'List of Tables' section is present.",
    },
    {
        "id": 4,
        "section_name": "Abbreviations",
        "question": "Is a list of abbreviations / glossary present?",
        "prompt": "Verify that abbreviations or a glossary section exists.",
    },
    {
        "id": 5,
        "section_name": "Storage",
        "question": "Are storage instructions specified?",
        "prompt": "Check if storage conditions and instructions are documented.",
    },
    {
        "id": 6,
        "section_name": "PCB Inspection REPORT",
        "question": "Is a PCB inspection report section present?",
        "prompt": "Verify whether a PCB inspection report template or section exists.",
    },
    {
        "id": 7,
        "section_name": "QA Matrix",
        "question": "Is a QA matrix provided?",
        "prompt": "Check if a Quality Assurance Matrix is included in the document.",
    },
    {
        "id": 8,
        "section_name": "Safety precautions",
        "question": "Are safety precautions documented?",
        "prompt": "Verify that safety precautions or safety instructions are present.",
    },
    {
        "id": 9,
        "section_name": "Packaging instructions",
        "question": "Are packaging / packing instructions provided?",
        "prompt": "Check if packaging or packing instructions are included.",
    },
    {
        "id": 10,
        "section_name": "List of figures",
        "question": "Is a list of figures present?",
        "prompt": "Verify if a 'List of Figures' section exists.",
    },
]


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _truncate(text: str, max_chars: int = 300) -> str:
    text = text.replace("\n", " ")
    return text[:max_chars] + " …" if len(text) > max_chars else text


def _print_node(node, indent: int = 0) -> None:
    prefix = "│   " * indent
    num = f"[{node.numeric_prefix}]" if node.numeric_prefix else "[special]"
    label = node.label[:70]
    print(f"{prefix}├── {num} {label}")
    print(f"{prefix}│   lines {node.start_line}–{node.end_line} "
          f"| content: {_truncate(node.own_content, 80)}")
    for child in node.children:
        _print_node(child, indent + 1)


def _status_icon(status: str) -> str:
    return {"exact": "✅", "good": "🟢", "partial": "🟡", "not_found": "❌"}.get(status, "?")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python test_section_extractor.py document.md [checklist.json]")
        sys.exit(1)

    md_path   = Path(sys.argv[1])
    cl_path   = Path(sys.argv[2]) if len(sys.argv) > 2 else None
    use_embed = "--no-embed" not in sys.argv

    print(f"\n{'='*70}")
    print(f" QAP Section Extractor – Test Run")
    print(f" Document : {md_path}")
    print(f" Embeddings: {'enabled (nomic-embed-text)' if use_embed else 'DISABLED'}")
    print(f"{'='*70}\n")

    # Read markdown
    md_text = md_path.read_text(encoding="utf-8", errors="replace")

    # Load checklist
    if cl_path and cl_path.exists():
        checklist = json.loads(cl_path.read_text(encoding="utf-8"))
    else:
        print("⚠  No checklist provided – using sample 10-item checklist.\n")
        checklist = SAMPLE_CHECKLIST

    # ── Extract sections ──────────────────────────────────────────────────
    print("Extracting sections …")
    result = extract_sections(md_text)

    print(f"\n{'─'*60}")
    print(f" TOC Entries detected: {len(result['toc_entries'])}")
    print(f"{'─'*60}")
    for e in result["toc_entries"][:15]:
        print(f"  [{ (e.get('numeric') or '–') :>8}]  {e['text'][:60]:<60}  p.{e['page']}")
    if len(result["toc_entries"]) > 15:
        print(f"  … and {len(result['toc_entries']) - 15} more")

    print(f"\n{'─'*60}")
    print(f" Preamble sections: {len(result['preamble'])}")
    print(f"{'─'*60}")
    for node in result["preamble"]:
        print(f"  [special]  {node.label[:60]}  "
              f"(lines {node.start_line}–{node.end_line})")

    print(f"\n{'─'*60}")
    print(f" Numbered section tree  ({len(result['tree'])} root nodes, "
          f"{len(result['flat']) - len(result['preamble'])} total nodes)")
    print(f"{'─'*60}")
    for root in result["tree"]:
        _print_node(root)

    # ── Match checklist ───────────────────────────────────────────────────
    print(f"\n{'─'*60}")
    print(f" Checklist Mapping ({len(checklist)} items, top-2 matches each)")
    print(f"{'─'*60}")

    matches = match_checklist_to_sections(
        checklist       = checklist,
        all_nodes       = result["flat"],
        top_k           = 2,
        use_embeddings  = use_embed,
    )

    for m in matches:
        icon = _status_icon(m["status"])
        print(f"\n{icon} [{m['checklist_id']:>2}] {m['checklist_section']}")
        print(f"       Status : {m['status'].upper()}  (best score {m['best_score']:.3f})")
        for match in m["matches"]:
            print(f"       Match #{match['rank']} [{match['match_tier']:>14}] "
                  f"score={match['score']:.3f}  →  {match['matched_heading'][:55]}")
            print(f"              lines {match['start_line']}–{match['end_line']}")
            print(f"              preview: {_truncate(match['content'], 120)}")

    print(f"\n{'='*70}")
    print(" Done.")
    print(f"{'='*70}\n")


if __name__ == "__main__":
    main()
