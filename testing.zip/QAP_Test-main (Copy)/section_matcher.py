"""
section_matcher.py  (v2)
========================
Maps checklist section names to extracted document nodes (section, table, figure).

Matching cascade per node:
  Tier 1 – Exact (normalized equality)              score = 1.00
  Tier 2 – Fuzzy (rapidfuzz token_sort_ratio)        score = ratio
  Tier 3 – Synonym dictionary (QAP domain)           score = 0.85
  Tier 4 – Embedding cosine sim (nomic-embed-text)   score = cosine

For each checklist item the output includes:
  tree_matches    – top-K matches from main section tree  (must have ≥ 1)
  table_matches   – top-K matches from table nodes        (≥ 1 if any match found)
  figure_matches  – top-K matches from figure nodes       (≥ 1 if any match found)
"""

from __future__ import annotations

import re
import logging
from typing import Optional

import numpy as np
import requests
from rapidfuzz import fuzz

from section_extractor import SectionNode, TableNode, FigureNode

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
OLLAMA_BASE_URL  = "http://172.27.30.222:12000"
EMBED_MODEL      = "nomic-embed-text"
FUZZY_THRESHOLD  = 0.68
EMBED_THRESHOLD  = 0.60


# ─────────────────────────────────────────────────────────────────────────────
#  Synonym groups (QAP / defence-electronics domain)
# ─────────────────────────────────────────────────────────────────────────────

SYNONYM_GROUPS: list[frozenset[str]] = [
    frozenset({
        "amendments sheet", "amendments record sheet", "record of amendments",
        "revision history", "amendment history", "amendment sheet",
        "amendment record", "record of amendment",
    }),
    frozenset({
        "introduction", "general requirements", "scope and purpose",
        "scope", "purpose", "overview", "introduction of system",
        "background", "general",
    }),
    frozenset({"list of tables", "list of table", "tables"}),
    frozenset({"list of figures", "list of figure", "figures"}),
    frozenset({"list of annexures", "list of annexure", "annexures", "annexure"}),
    frozenset({
        "abbreviations", "abbreviation", "list of abbreviations",
        "list of abbreviation", "acronyms", "glossary", "list of acronyms",
    }),
    frozenset({
        "deliverables", "delivery set list", "list of delivery",
        "scope of work", "scope of delivery", "list of deliverables",
        "delivery set",
    }),
    frozenset({
        "storage", "storage details", "storage temperature",
        "operating and storage temperature", "storage instruction",
        "storage conditions",
    }),
    frozenset({
        "packaging instructions", "packaging", "package instructions",
        "packing", "packaging instruction", "unit packaging",
    }),
    frozenset({
        "transportation instruction", "transportation",
        "transport instruction", "handling",
    }),
    frozenset({
        "pcb inspection report", "pcb inspection",
        "bare pcb inspection report", "populated pcb inspection report",
        "pcb inspection checklist", "bare pcb",
    }),
    frozenset({
        "qa matrix", "quality assurance matrix", "qap matrix",
        "mechanical qa matrix", "electrical qa matrix",
        "quality assurance plan matrix", "qa/qc matrix",
    }),
    frozenset({
        "safety precautions", "safety precaution", "safety",
        "safety instruction", "safety instructions", "esd",
    }),
    frozenset({
        "retention checks", "records", "record retention",
        "quality records", "records control",
    }),
    frozenset({
        "traceability", "traceability and identification",
        "identification", "serial number tracking",
    }),
    frozenset({
        "incoming inspection", "incoming goods inspection",
        "incoming good inspection", "incoming inspection stage",
        "incoming material", "incoming quality check",
    }),
    frozenset({
        "bom inspection", "bill of materials inspection",
        "bom verification", "populated pcb bom check",
    }),
    frozenset({
        "qualification test", "qualification test flow chart",
        "qt flow chart", "qualification test procedure", "qt flow",
    }),
    frozenset({
        "acceptance test", "acceptance test flow chart",
        "at flow chart", "acceptance test procedure", "at flow",
        "acceptance test sequence",
    }),
    frozenset({
        "emi emc testing", "emi emc", "emi/emc testing",
        "electromagnetic interference", "mil std 461",
    }),
    frozenset({
        "test templates", "inspection reports", "test report templates",
        "annexures", "report templates", "test forms",
    }),
    frozenset({
        "governing documents", "reference documents", "reference standards",
        "applicable documents", "standards", "supply orders",
    }),
]

_SYNONYM_LOOKUP: dict[str, int] = {}
for _gi, _group in enumerate(SYNONYM_GROUPS):
    for _term in _group:
        _SYNONYM_LOOKUP[_term] = _gi


# ─────────────────────────────────────────────────────────────────────────────
#  Normalization
# ─────────────────────────────────────────────────────────────────────────────

def normalize(text: str) -> str:
    t = text.lower().strip()
    t = re.sub(r"^\d[\d.]*\.?\s+", "", t)     # strip numeric prefix
    t = re.sub(r"[^a-z0-9\s]", " ", t)
    return re.sub(r"\s+", " ", t).strip()


# ─────────────────────────────────────────────────────────────────────────────
#  Tier scorers
# ─────────────────────────────────────────────────────────────────────────────

def exact_score(a: str, b: str) -> float:
    return 1.0 if normalize(a) == normalize(b) else 0.0


def fuzzy_score(a: str, b: str) -> float:
    return fuzz.token_sort_ratio(normalize(a), normalize(b)) / 100.0


def synonym_score(a: str, b: str) -> float:
    n1, n2 = normalize(a), normalize(b)
    g1 = _SYNONYM_LOOKUP.get(n1)
    g2 = _SYNONYM_LOOKUP.get(n2)
    if g1 is not None and g2 is not None and g1 == g2:
        return 0.85
    # Partial substring match within a synonym group
    for term, gi in _SYNONYM_LOOKUP.items():
        if n1 in term or term in n1:
            if _SYNONYM_LOOKUP.get(n2) == gi:
                return 0.78
    return 0.0


# ─────────────────────────────────────────────────────────────────────────────
#  Embedding (Tier 4)
# ─────────────────────────────────────────────────────────────────────────────

_embed_cache: dict[str, Optional[np.ndarray]] = {}


def get_embedding(text: str, base_url: str = OLLAMA_BASE_URL) -> Optional[np.ndarray]:
    if text in _embed_cache:
        return _embed_cache[text]
    try:
        resp = requests.post(
            f"{base_url}/api/embeddings",
            json={"model": EMBED_MODEL, "prompt": text},
            timeout=30,
        )
        resp.raise_for_status()
        vec = np.array(resp.json()["embedding"], dtype=np.float32)
        _embed_cache[text] = vec
        return vec
    except Exception as exc:
        logger.warning(f"Embedding failed for '{text[:40]}': {exc}")
        _embed_cache[text] = None
        return None


def cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def embedding_score(a: str, b: str, base_url: str = OLLAMA_BASE_URL) -> float:
    e1 = get_embedding(normalize(a), base_url)
    e2 = get_embedding(normalize(b), base_url)
    if e1 is None or e2 is None:
        return 0.0
    return cosine_sim(e1, e2)


# ─────────────────────────────────────────────────────────────────────────────
#  Score a (checklist_section, heading_text) pair
# ─────────────────────────────────────────────────────────────────────────────

def _score(
    checklist_section: str,
    heading: str,
    use_embeddings: bool,
    base_url: str,
) -> tuple[float, str]:
    """Returns (best_score, tier_name)."""
    s1 = exact_score(checklist_section, heading)
    if s1 == 1.0:
        return 1.0, "exact"

    s2 = fuzzy_score(checklist_section, heading)
    s3 = synonym_score(checklist_section, heading)

    best = max(s2, s3)
    tier = "fuzzy" if s2 >= s3 else "synonym"

    if best >= FUZZY_THRESHOLD:
        return best, tier

    if use_embeddings:
        s4 = embedding_score(checklist_section, heading, base_url)
        if s4 > best:
            return s4, "embedding"

    return best, tier + "_low"


# ─────────────────────────────────────────────────────────────────────────────
#  Match against section tree nodes
# ─────────────────────────────────────────────────────────────────────────────

def _match_section_nodes(
    checklist_section: str,
    nodes: list[SectionNode],
    top_k: int,
    use_embeddings: bool,
    base_url: str,
) -> list[dict]:
    scored = []
    for node in nodes:
        sc, tier = _score(checklist_section, node.heading.text, use_embeddings, base_url)
        scored.append((sc, tier, node))

    scored.sort(key=lambda x: -x[0])
    results = []
    for rank, (sc, tier, node) in enumerate(scored[:top_k], 1):
        results.append({
            "rank":            rank,
            "matched_heading": node.heading.text,
            "numeric_prefix":  node.heading.numeric,
            "match_tier":      tier,
            "score":           round(sc, 4),
            "content":         node.content,
            "start_line":      node.start_line,
            "end_line":        node.end_line,
            "is_special":      node.heading.is_special,
        })
    return results


# ─────────────────────────────────────────────────────────────────────────────
#  Match against table nodes
# ─────────────────────────────────────────────────────────────────────────────

def _match_table_nodes(
    checklist_section: str,
    table_nodes: list[TableNode],
    top_k: int,
    use_embeddings: bool,
    base_url: str,
) -> list[dict]:
    scored = []
    for tbl in table_nodes:
        sc, tier = _score(checklist_section, tbl.title, use_embeddings, base_url)
        scored.append((sc, tier, tbl))

    scored.sort(key=lambda x: -x[0])
    results = []
    for rank, (sc, tier, tbl) in enumerate(scored[:top_k], 1):
        # Only include if there's a meaningful match
        if sc < 0.35:
            continue
        results.append({
            "rank":        rank,
            "table_title": tbl.title,
            "match_tier":  tier,
            "score":       round(sc, 4),
            "content":     tbl.cell_text[:8000],
            "start_line":  tbl.start_line,
            "end_line":    tbl.end_line,
        })
    return results


# ─────────────────────────────────────────────────────────────────────────────
#  Match against figure nodes
# ─────────────────────────────────────────────────────────────────────────────

def _match_figure_nodes(
    checklist_section: str,
    figure_nodes: list[FigureNode],
    top_k: int,
    use_embeddings: bool,
    base_url: str,
) -> list[dict]:
    scored = []
    for fig in figure_nodes:
        sc, tier = _score(checklist_section, fig.caption, use_embeddings, base_url)
        scored.append((sc, tier, fig))

    scored.sort(key=lambda x: -x[0])
    results = []
    for rank, (sc, tier, fig) in enumerate(scored[:top_k], 1):
        if sc < 0.35:
            continue
        results.append({
            "rank":        rank,
            "caption":     fig.caption,
            "ref":         fig.ref,
            "match_tier":  tier,
            "score":       round(sc, 4),
            "context":     fig.context,
            "line_num":    fig.line_num,
        })
    return results


# ─────────────────────────────────────────────────────────────────────────────
#  Pre-compute embeddings
# ─────────────────────────────────────────────────────────────────────────────

def precompute_embeddings(
    nodes: list[SectionNode],
    table_nodes: list[TableNode],
    figure_nodes: list[FigureNode],
    base_url: str = OLLAMA_BASE_URL,
) -> None:
    for node in nodes:
        get_embedding(normalize(node.heading.text), base_url)
    for tbl in table_nodes:
        get_embedding(normalize(tbl.title), base_url)
    for fig in figure_nodes:
        get_embedding(normalize(fig.caption), base_url)


# ─────────────────────────────────────────────────────────────────────────────
#  Public API
# ─────────────────────────────────────────────────────────────────────────────

def match_checklist_to_sections(
    checklist:       list[dict],
    all_nodes:       list[SectionNode],
    table_nodes:     list[TableNode]  = None,
    figure_nodes:    list[FigureNode] = None,
    top_k:           int  = 2,
    use_embeddings:  bool = True,
    ollama_base_url: str  = OLLAMA_BASE_URL,
) -> list[dict]:
    """
    Map every checklist item to the top-K matches from:
      • main section tree nodes
      • table nodes
      • figure nodes

    Returns list of result dicts, one per checklist item.
    Each result dict:
    {
        "checklist_id"     : int,
        "checklist_section": str,
        "question"         : str,
        "prompt"           : str,
        "status"           : "exact"|"good"|"partial"|"not_found",
        "best_score"       : float,
        "tree_matches"     : [list of section match dicts],
        "table_matches"    : [list of table match dicts],
        "figure_matches"   : [list of figure match dicts],
        # legacy compatibility
        "matches"          : same as tree_matches
    }
    """
    table_nodes  = table_nodes  or []
    figure_nodes = figure_nodes or []

    if use_embeddings:
        logger.info("Pre-computing node embeddings …")
        precompute_embeddings(all_nodes, table_nodes, figure_nodes, ollama_base_url)

    results: list[dict] = []

    for item in checklist:
        section_name = item.get("section_name", "")

        tree_matches   = _match_section_nodes(
            section_name, all_nodes, max(top_k, 2), use_embeddings, ollama_base_url
        )
        table_matches  = _match_table_nodes(
            section_name, table_nodes, top_k, use_embeddings, ollama_base_url
        )
        figure_matches = _match_figure_nodes(
            section_name, figure_nodes, top_k, use_embeddings, ollama_base_url
        )

        # Overall status based on best score across ALL match types
        all_scores = (
            [m["score"] for m in tree_matches]
            + [m["score"] for m in table_matches]
            + [m["score"] for m in figure_matches]
        )
        best = max(all_scores) if all_scores else 0.0

        if best >= 0.95:
            status = "exact"
        elif best >= FUZZY_THRESHOLD:
            status = "good"
        elif best >= 0.40:
            status = "partial"
        else:
            status = "not_found"

        results.append({
            "checklist_id"     : item.get("id"),
            "checklist_section": section_name,
            "question"         : item.get("question", ""),
            "prompt"           : item.get("prompt", ""),
            "status"           : status,
            "best_score"       : round(best, 4),
            "tree_matches"     : tree_matches,
            "table_matches"    : table_matches,
            "figure_matches"   : figure_matches,
            "matches"          : tree_matches,   # legacy compat for llm_verifier
        })

    return results
