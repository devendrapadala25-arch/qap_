"""
pdf_converter.py
================
Converts a PDF file to Markdown using MinerU (magic-pdf CLI).
Falls back to providing helpful error messages if MinerU is not installed.

MinerU output layout (version 0.9+):
  output_dir/
    <pdf_stem>/
      <method>/            ← auto | vlm | ocr | txt
        <pdf_stem>.md
        images/
        ...
"""

from __future__ import annotations
import time
import os
os.environ['HOME'] = "/media/dlpda/data/shivam_backup/PROD_TESTING/shivam/mineru/mineru_model_home/content/datt"
#os.environ['HOME'] = "/media/dlpda/data/shivam_backup/PROD_TESTING/shivam/m_mineru/hmz"
import subprocess, shlex, pathlib
import sys
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

# Supported MinerU methods (shown to user in UI)
MINERU_METHODS = {
    "auto":   "Auto (Recommended) — hybrid layout + OCR",
    "vlm":    "VLM — Vision-Language Model (best for complex layouts)",
    "ocr":    "OCR — Pure OCR (fallback for scanned pages)",
    "txt":    "TXT — Text extraction only (fastest, no OCR)",
}


def _find_output_md(output_dir: Path, pdf_stem: str, method: str) -> Path | None:
    """
    Locate the output .md file produced by MinerU.
    Tries the canonical path first, then a recursive glob.
    """
    # Canonical path: output_dir/<stem>/<method>/<stem>.md
    canonical = output_dir / pdf_stem / method / f"{pdf_stem}.md"
    if canonical.exists():
        return canonical

    # Recursive fallback (handles minor version differences)
    md_files = sorted(output_dir.rglob("*.md"))
    for f in md_files:
        stem_lower   = pdf_stem.lower()
        fname_lower  = f.name.lower()
        # Exclude auxiliary files
        excluded = any(kw in fname_lower for kw in
                       ("content_list", "middle", "model", "layout"))
        if not excluded and stem_lower in fname_lower:
            return f

    # Last resort: any .md file
    return md_files[0] if md_files else None


def convert_pdf_to_markdown(
    pdf_path: str | Path,
    output_dir: str | Path,
    method: str = "auto",
    timeout: int = 10800,
) -> tuple[str, str]:
    """
    Convert a PDF file to Markdown using the MinerU CLI (magic-pdf).

    Args:
        pdf_path:   Absolute path to the input PDF.
        output_dir: Directory where MinerU will write its output.
        method:     MinerU parse method: "auto" | "vlm" | "ocr" | "txt".
        timeout:    Max seconds to wait for conversion (default 10800 = 180 min).

    Returns:
        (markdown_text, md_file_path) on success.

    Raises:
        FileNotFoundError: If magic-pdf is not installed or output .md not found.
        RuntimeError:      If the conversion process fails.
    """
    """
    pdf_path   = Path(pdf_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── Build command ─────────────────────────────────────────────────────
    # Try "magic-pdf" first; some installations use "mineru"
    cmd_candidates = [
        ["magic-pdf", "-p", str(pdf_path), "-o", str(output_dir), "-m", method],
        ["mineru",    "-p", str(pdf_path), "-o", str(output_dir), "-m", method],
        [sys.executable, "-m", "magic_pdf", "-p", str(pdf_path),
         "-o", str(output_dir), "-m", method],
    ]

    last_error = ""
    for cmd in cmd_candidates:
        try:
            logger.info(f"Running: {' '.join(cmd)}")
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            if proc.returncode == 0:
                break
            last_error = proc.stderr or proc.stdout
        except FileNotFoundError:
            last_error = f"Command not found: {cmd[0]}"
            continue
        except subprocess.TimeoutExpired:
            raise RuntimeError(
                f"MinerU conversion timed out after {timeout} seconds. "
                "Try a shorter document or increase the timeout."
            )
    else:
        raise FileNotFoundError(
            "MinerU (magic-pdf) is not installed or not on PATH.\n"
            "Install it with:  pip install magic-pdf[full]\n"
            f"Last error: {last_error}"
        )

    if proc.returncode != 0:
        raise RuntimeError(
            f"MinerU conversion failed (exit {proc.returncode}).\n"
            f"stderr: {last_error[:1000]}"
        )
    """
    #pdf_path=str(pdf_path)
    #output_dir=str(output_dir)
    cmd = f"mineru -p {shlex.quote(str(pdf_path))} -o {shlex.quote(str(output_dir))} -b hybrid-auto-engine"
    #cmd = f"mineru -p {shlex.quote(str(pdf_path))} -o {shlex.quote(str(output_dir))} -b vlm-auto-engine"
    subprocess.run(cmd, shell=True, check=True)

    # ── Locate output .md ─────────────────────────────────────────────────
    md_file = _find_output_md(output_dir, pdf_path.stem, method)
    if md_file is None:
        raise FileNotFoundError(
            f"MinerU ran successfully but no .md file found in {output_dir}.\n"
            f"Contents: {[str(p) for p in output_dir.rglob('*')][:20]}"
        )

    md_text = md_file.read_text(encoding="utf-8", errors="replace")
    logger.info(f"Markdown produced: {md_file}  ({len(md_text):,} chars)")
    return md_text, str(md_file)


def is_mineru_available() -> bool:
    """Return True if magic-pdf is callable from the current PATH."""
    for cmd in ("magic-pdf", "mineru"):
        try:
            result = subprocess.run(
                [cmd, "--version"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0 or "usage" in result.stderr.lower():
                return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    return False
